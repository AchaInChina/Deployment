/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

DBTabs = {
	tabs			: null,
	count			: 0,
	queryCache		: {},
	cmMenuType		: null,
	tabTemplate		: "<li><a href='##href##'>##label##</a> <span class='ui-icon ui-icon-close' role='presentation'>##STRREMOVETABS##</span></li>",
	
	init : function() {
		DBTabs.tabs = $("#databaseTabs").tabs();
		DBTabs.tabs.delegate("span.ui-icon-close", "click", DBTabs.removeTab);
		DBTabs.tabs.delegate(".btnDB_Refresh","click", DBTabs.btnRefresh);
		DBTabs.tabs.delegate(".btnDB_Edit","click", DBTabs.btnEdit);
		DBTabs.tabs.delegate(".btnDB_Export","click", DBTabs.btnExport);
		DBTabs.tabs.delegate(".dbDocIconToggle","click", DBTabs.expandDoc);
		DBTabs.tabs.delegate(".dbDocProperty","dblclick", function() { DBTabs.setFieldValue($(this)); });
		
		DBTabs.tabs.delegate(".dbDocSelectable","click", function() {
			var target	= $(this);
			var tabID	= target.closest(".databaseTabsContent").attr("id");
				
			$("#"+tabID+" .dbDocSelected").removeClass("dbDocSelected");
			target.addClass("dbDocSelected");
		});
		
		
		DBTabs.tabs.contextmenu({
			delegate: ".dbDocSelectable",
			menu: "#cm_Document",
			preventSelect : false,
			beforeOpen :function(event, ui) {
				var target	= $(ui.target);
				var tabID	= target.closest(".databaseTabsContent").attr("id");
				var qryID	= $("#"+tabID).data("id");
				var query	= DBTabs.queryCache[qryID];
				
				switch (query.mongoCmd) {
					case "AGGREGATE"	:
					case "FINDMODIFY"	:
					case "DISTINCT"		:
					case "COMMAND"		:
						return false;
					break;
				}
								
				$("#"+tabID+" .dbDocSelected").removeClass("dbDocSelected");
				
				if (!target.hasClass("dbDocSelectable")) {
					target = target.closest(".dbDocSelectable");
				}
				
				target.addClass("dbDocSelected");					
				
				if (target.hasClass("dbDocRoot")) {
					DBTabs.cmMenuType = "onDocument";
					$(this).contextmenu("replaceMenu", "#cm_Document");
				} else if (target.hasClass("dbDocSubTree")) {
					DBTabs.cmMenuType = "onSubTree";
					$(this).contextmenu("replaceMenu", "#cm_DocumentSubTree");
				} else if (target.hasClass("dbDocProperty")) {
					DBTabs.cmMenuType = "onField";
					$(this).contextmenu("replaceMenu", "#cm_DocumentField");
				}
			},
			select : function(event, ui) {
				var target	= $(ui.target);
				
				if (!target.hasClass("dbDocSelectable")) {
					target = target.closest(".dbDocSelectable");
				}	
				
				switch (DBTabs.cmMenuType) {
					case "onDocument" :
						switch (ui.cmd) {
							case "update" : DBTabs.updateDoc(target); break;
							case "remove" : DBTabs.removeDoc(target); break;
						}
					break;
					
					case "onSubTree" :
						switch (ui.cmd) {
							case "unsetField"	: DBTabs.unsetField(target); break;
						}						
					break;
					
					case "onField" :
						switch (ui.cmd) {
							case "setValue"		: DBTabs.setFieldValue(target); break;
							case "unsetField"	: DBTabs.unsetField(target); break;
						}
					break;
				}
			}
		});
	},
	
	createTab	: function(id, tabID, tabLabel) {
		var li = $(DBTabs.tabTemplate.replaceList({"##href##" : "#"+tabID, "##label##" : tabLabel, "##STRREMOVETABS##" : i18n.TABS_REMOVETAB }));
		
		if (!DBTabs.tabs.is(":visible")) DBTabs.tabs.show();
		
		var html = 
			'<div id="' + tabID + '" class="databaseTabsContent" data-id="'+id+'" style="padding: 5px 5px">' +
				'<div style="height:35px; width:100%;">' +
					'<div class="btnDB btnDB_Refresh" title="'+i18n.LABEL_FINDREFRESH+'"></div>' +
					'<div class="btnDB btnDB_Edit" title="'+i18n.LABEL_FINDEDIT+'"></div>' +
					'<div class="btnDB btnDB_Export" title="'+i18n.LABEL_FINDEXPORT+'"></div>' +
					'<div class="clear"></div>'+
				'</div>' +
				'<div class="databaseTabsResult"></div>' +
			'</div>';
		
		DBTabs.tabs.find( ".ui-tabs-nav" ).append(li);
		DBTabs.tabs.append(html);
		DBTabs.tabs.tabs("refresh");
		DBTabs.tabs.tabs({"active" : DBTabs.count });
		DBTabs.count++;
		
		$("#"+tabID).height($("#databaseOper").height() - $("#databaseTabs ul").height() -18);
	},

	
	removeTab : function() {		
		var panelID = $( this ).closest( "li" ).remove().attr( "aria-controls" );
		
		$("#" + panelID).remove();
	    DBTabs.tabs.tabs("refresh");
			    
		delete DBTabs.queryCache[panelID.slice(panelID.indexOf("-")+1)];
		DBTabs.count--;
		
		if (DBTabs.count <= 0) {
			DBTabs.tabs.hide();
		}
	},

	renderResult : function(id, result) {
		var query	= DBTabs.queryCache[id];
		var tabID	= "QueryTab-"+id;
		var doc		= null;
		var html	= "";		
		
		if (!$("#"+tabID).length) {
			DBTabs.createTab(id, tabID, query.mongoCmd+ " " +query.path.database + (query.path.collection ? "."+query.path.collection : ""));
		} else {
			$("#"+tabID+" .databaseTabsResult").html("");
		}
				
		for (var i in query.result) {
			doc = query.result[i];
			
			html = '<div class="dbDoc" data-idx="'+i+'"><span class="ui-icon ui-icon-plus dbDocIconToggle dbPlusRoot" data-state="closed" style="display:inline-block"></span><span class="dbDocRoot dbDocSelectable dbDocTitle">'+JSON.stringify(doc)+'</span><span class="dbDocBody" data-path="" data-type="object"></span></div>';
			$("#"+tabID+" .databaseTabsResult").append(html);			
		}		
	},
	
	execQuery	: function(id, success) {
		var query = DBTabs.queryCache[id];
		
		var fnSuccess = function(result) {
			query.result = result;
			DBTabs.renderResult(id, result);
			Spinner.close();
			if (success) success();
		};
		
		var fnError	= function(error) {
			Spinner.close();
			LOG.error("ERROR Executing "+query.mongoCmd+" query");			
		};
		
		var fnRefreshDB = function(result) {
			fnSuccess(result);
			DBTree.refreshDatabase({"server":query.path.server,"database":query.path.database});			
		};
				
		switch (query.mongoCmd) {
			case "FIND"			:  new Struct.Collection().find(query, fnSuccess, fnError); break;
			case "AGGREGATE"	:  new Struct.Collection().aggregate(query, fnSuccess, fnError); break;
			case "DISTINCT"		:  new Struct.Collection().distinct(query, fnSuccess, fnError); break;
			case "FINDMODIFY"	:  new Struct.Collection().findModify(query, fnRefreshDB, fnError); break;
			case "COMMAND"		:  new Struct.DB().command(query, fnRefreshDB, fnError); break;
		}
	},
	
	setQuery : function(query, success) {
		DBTabs.queryCache[query.id] = query;
		DBTabs.execQuery(query.id, success);
	},	
	
	getQuery : function(id, merge) {
		var qy = DBTabs.queryCache[id];
		qy = (qy ? qy : {});
		
		if (merge) {			
			return $.extend(qy,merge);
		}
		
		return qy;
	},
	
	getNode : function(path, doc) {
		if (path == "") return doc;
		
		var pos		= (path.indexOf(".") >= 0 ? path.indexOf(".") : path.length);
		var name	= path.slice(0,pos);
		var node	= doc[name];		
				
		return DBTabs.getNode(path.slice(pos+1,path.length),node);
	},
	
	setNode : function(path, doc, value) {
		if (path.indexOf(".") == -1) {
			doc[path] = value;
		} else {
			var pos		= (path.indexOf(".") >= 0 ? path.indexOf(".") : path.length);
			var nPath	= path.slice(0,pos);
			
			DBTabs.setNode(nPath,doc,value);
		}		
	},
	
	removeNode : function(path, doc) {
		var pos		= (path.indexOf(".") >= 0 ? path.indexOf(".") : path.length);
		var name	= path.slice(0,pos);

		if (path == name) {
			if (Helper.Object.getObjectType(doc) == "array") {
				doc = doc.splice(Number(path),1);
			} else {
				delete(doc[name]);
			}
		} else {
			DBTabs.removeNode(path.slice(pos+1,path.length),doc[name]);
		}		
	},
	
	
	btnRefresh : function(event, ui) {
		Spinner.open(i18n.SPN_LOADFINDRESULT);
		DBTabs.execQuery($(this).closest(".databaseTabsContent").data("id"));
	},
		
	
	btnEdit : function(event, ui) {
		var query = DBTabs.queryCache[$(this).closest(".databaseTabsContent").data("id")];
		
		switch (query.mongoCmd) {
			case "FIND"			: Dialog.Find.open(query.path, {query : query}); break;
			case "FINDMODIFY"	: Dialog.FindModify.open(query.path, {query : query}); break;
			case "AGGREGATE"	: Dialog.Aggregate.open(query.path, {query : query}); break;
			case "DISTINCT"		: Dialog.Distinct.open(query.path, {query : query}); break;
			case "COMMAND"		: Dialog.Command.open(query.path, {query : query}); break;
		}
	},
	
	btnExport : function(events, ui) {
		var query		= DBTabs.queryCache[$(this).closest(".databaseTabsContent").data("id")];
		var bControl	= new Backend.Control();

		bControl.saveJSON({
			fileName : "find-export."+Helper.Date.formatDateTimeISOMinified()+".json",
			fileBody : JSON.stringify(query.result) 
		});
	},
	
	concatPath : function(curr, next) {
		return curr + (curr != "" ? "." : "")+next;
	},
	
	getLastOfPath : function(path) {
		var pos = path.lastIndexOf(".");
		
		return (pos >= 0 ? path.slice(pos+1,path.length) : path);
	},
	
	getObjectSubType	: function(obj) {
		if (obj == null)	return "null";
		if (obj["$date"])	return "date";
	},
	
	getDateFromObject : function(obj) {
		var date = new Date(obj["$date"]);
		return date.dateFormat(i18n.FORMAT_DATETIME);
	},
	
	printExpandedDocNode : function(path, docNode) {
		var html = "";

		for (var name in docNode) {
			item	= docNode[name];
			vType	= Helper.Object.getObjectType(item);
				
			switch (vType) {
				case "object" :
					var objType = DBTabs.getObjectSubType(item);
					
					switch (objType) {
						case "null" :
							html += '<li><span class="dbDocProperty dbDocSelectable"><span class="dbDocPropID" title="null">' + name + '</span>: <span class="docPropValue">NULL</span></span>';
						break;
						
						case "date" :
							html += '<li><span class="dbDocProperty dbDocSelectable"><span class="dbDocPropID" title="date">' + name + '</span>: <span class="docPropValue">' + DBTabs.getDateFromObject(item) + '</span></span>';
						break;
						
						default	:
							html += 
								'<li>'+
								'<span class="ui-icon ui-icon-plus dbDocIconToggle dbPlus" data-state="closed" style="display:inline-block"></span>' +
								'<span class="dbDocTitle dbDocSubTree dbDocSelectable"><span class="dbDocPropID" title="object">'+name + "</span> : " + JSON.stringify(item)+'</span><span class="dbDocBody" data-path="'+DBTabs.concatPath(path,name)+'" data-type="object"></span>';
					}
				break;
				
				case "array" :
					html += 
						'<li>'+
						'<span class="ui-icon ui-icon-plus dbDocIconToggle dbPlus" data-state="closed" style="display:inline-block"></span>' +
						'<span class="dbDocTitle dbDocSubTree dbDocSelectable"><span class="dbDocPropID" title="array">'+name + "</span> : " + JSON.stringify(item)+'</span><span class="dbDocBody" data-path="'+DBTabs.concatPath(path,name)+'" data-type="array"></span>';
				break;
				
				case "double" :
					html += '<li><span class="dbDocProperty dbDocSelectable"><span class="dbDocPropID" title="'+vType+'">' + name + '</span>: <span class="docPropValue">' + item.formatDouble(12,i18n.FORMAT_NUMBER_DECIMALSEP, i18n.FORMAT_NUMBER_THOUSANDSEP) + '</span></span>';
				break;
				
				default :
					html += '<li><span class="dbDocProperty dbDocSelectable"><span class="dbDocPropID" title="'+vType+'">' + name + '</span>: <span class="docPropValue">' + item + '</span></span>';
			}
			
			html += '</li>';
		}
		
		return html;
	},
	
	expandDoc : function(event, ui) {
		var uiDoc	= $(this).closest(".dbDoc");		
		var id		= uiDoc.closest(".databaseTabsContent").data("id");
		var idx		= uiDoc.data("idx");
		var doc		= DBTabs.queryCache[id].result[idx];
		
		var path	= $(this).nextAll(".dbDocBody").data("path");
		var docNode	= DBTabs.getNode(path,doc);
		var html 	= "";
		var htmlTi	= "";
		var item	= null;
		var vType	= null;
		var json	= JSON.stringify(docNode);
		
		switch ($(this).data("state")) {
			case "closed" :
				$(this).data("state","opened");
				$(this).removeClass("ui-icon-plus").addClass("ui-icon-minus");
				
				
				htmlTi	=
					(path != "" ? '<span class="dbDocPropID" title="Object">'+DBTabs.getLastOfPath(path) + '</span> : ' : "") +
					json.substr(0,150) +
					(json.length == 150 ? " ..." : "");
				
				
				html += '<ul>';
				html += DBTabs.printExpandedDocNode(path, docNode);
				html += '</ul>';
			break;
			
			case "opened" :				
				$(this).data("state","closed");
				$(this).removeClass("ui-icon-minus").addClass("ui-icon-plus");
				
				htmlTi	= (path != "" ? '<span class="dbDocPropID dbDocSelectable" title="Object">'+DBTabs.getLastOfPath(path) + '</span> : ' : "") + json;				
				html	= "";
			break;
		}
		
		$(this).nextAll(".dbDocTitle").html(htmlTi);
		$(this).nextAll(".dbDocBody").html(html);
	},
	
	getDocProps : function(elDocTitle) {
		var uiDoc	= elDocTitle.closest(".dbDoc");		
		var id		= uiDoc.closest(".databaseTabsContent").data("id");
		var idx		= uiDoc.data("idx");
		var query	= DBTabs.queryCache[id];
		var doc		= query.result[idx];
		
		return {
			"queryID"	: id,
			"queryPath" : query.path,
			"docID"		: { "_id" : doc["_id"] },
			"doc"		: doc
		}
	},
	
	updateDoc : function(elDocField) {
		var docProps	= DBTabs.getDocProps(elDocField);
		
		if (!docProps.docID["_id"]) {
			Dialog.AlertWarning.open({ message : i18n.ALERT_CANNOTUPDATE_NOID });
			return;
		}
		
		Dialog.Update.Document.open(elDocField, docProps);
	},
	
	removeDoc : function(elDocTitle) {
		var docProps = DBTabs.getDocProps(elDocTitle);
		
		if (!docProps.docID["_id"]) {
			Dialog.AlertWarning.open({ message : i18n.ALERT_CANNOTREMOVE_NOID });
			return;
		}
		
		Dialog.Confirmation.open({
			message: i18n.CONFIRM_REMOVEDOC
		}, function() {
			var coll		= new Struct.Collection();
			
			Spinner.open(i18n.SPN_REMOVINGDOC);
			coll.remove({ "path" : docProps.queryPath, "query" : docProps.docID}, function(result) {
				if (result.affected == 1) {
					DBTree.refreshDatabase({"server":docProps.queryPath.server,"database":docProps.queryPath.database});
					DBTabs.execQuery(docProps.queryID);					
					Dialog.AlertSuccess.open({ message : i18n.ALERT_DOCREMOVE_SUCCESS});
				} else {
					Spinner.close();
					Dialog.AlertWarning.open({ message : i18n.ALERT_DOCREMOVE_NOTREMOVED});
				}
			}, function(error) {
				Dialog.AlertSuccess.open({ message : i18n.ALERT_DOCREMOVE_ERROR});
			});
		});
	},
	
	
	getFieldProps : function(elDocField) {
		var queryID	= elDocField.closest(".databaseTabsContent").data("id");
		var docIdx	= elDocField.closest(".dbDoc").data("idx");
		var query	= DBTabs.queryCache[queryID];
		var doc		= query.result[docIdx];
		var fType	= elDocField.children(".dbDocPropID").attr("title");
		var pType	= elDocField.closest(".dbDocBody").data("type");
		var pPath	= elDocField.closest(".dbDocBody").data("path");
		var updID	= (pPath && pPath != "" ? pPath+"." : "") +elDocField.children(".dbDocPropID").html();
		
		return {
			"doc"		: doc,
			"queryID"	: queryID,
			"queryPath"	: query.path,
			"docID"		: {"_id" : doc["_id"] },
			"updID"		: updID,
			"fType"		: fType,
			"pPath"		: pPath,
			"pType"		: pType
		}
	},
	
	setFieldValue : function(elDocField) {
		var dProps	= DBTabs.getFieldProps(elDocField);
		var editor	= null;
		
		if (!dProps.docID["_id"]) {
			Dialog.AlertWarning.open({ message : i18n.ALERT_CANNOTUPDATE_NOID });
			return;
		}		
		
		switch (dProps.fType) {
			case "date"		: editor = DBTabs.FieldEditor.Date;		break;
			case "integer"	: editor = DBTabs.FieldEditor.Integer;	break;
			case "double"	: editor = DBTabs.FieldEditor.Double;	break;
			case "boolean"	: editor = DBTabs.FieldEditor.Boolean;	break;
			default			: editor = DBTabs.FieldEditor.String;	break;
		}

		switch (dProps.fType) {
			case "date" 	: dProps.updVal = this.getNode(dProps.updID,dProps.doc)['$date']; break;
			case "boolean"	:
			case "double"	: dProps.updVal = this.getNode(dProps.updID,dProps.doc); break;
			default			: dProps.updVal = elDocField.children(".docPropValue").html();		
		}
		
		editor.open(elDocField.children(".docPropValue"), dProps);
	},
	
	unsetField	: function (elDocField) {
		var dProps	= DBTabs.getFieldProps(elDocField);
		
		if (!dProps.docID["_id"]) {
			Dialog.AlertWarning.open({ message : i18n.ALERT_CANNOTREMOVE_NOID });
			return;
		}		
		
		Dialog.Confirmation.open({
			message: i18n.CONFIRM_REMOVEFIELD.replace("##FIELD##",dProps.updID)
		}, function() {
			var fnERROR = function() { Spinner.close(); Dialog.AlertError.open({ message : i18n.ALERT_DOCUNSETFIELD_ERROR.replace("##FIELD##",dProps.updID)}); };
			var coll	= new Struct.Collection();
			Spinner.open(i18n.SPN_UNSETTINGFIELD);

			coll.unsetField({
				path	: dProps.queryPath,
				id		: dProps.docID,
				fieldID	: dProps.updID
			}, function(result) {
				if (result.affected == 1) {
					var okFN = function() {
						DBTabs.removeNode(dProps.updID, dProps.doc);						
						
						switch (dProps.pType) {
							case "array" :
								elDocField.closest("ul").html(DBTabs.printExpandedDocNode(dProps.pPath, DBTabs.getNode(dProps.pPath,dProps.doc)));
							break;
							
							case "object" :
								elDocField.closest("li").remove();
							break;
						}
						
						Spinner.close();						
						Dialog.AlertSuccess.open({ message : i18n.ALERT_DOCUNSETFIELD_SUCCESS.replace("##FIELD##",dProps.updID)});						 
					};
					
					if (dProps.pType == "array") {
						var arr		= {}; 
						var arrID	= dProps.updID.slice(0,dProps.updID.lastIndexOf("."));						
						arr[arrID]	= null;
						
						coll.update({
							path	: dProps.queryPath,
							query	: { "_id" : dProps.docID },
							body	: { "$pull" : arr}
						}, okFN, fnERROR); 
					} else {
						okFN();
					}
				} else {
					Spinner.close();
					Dialog.AlertWarning.open({ message : i18n.ALERT_DOCUNSETFIELD_NOTUNSET.replace("##FIELD##",dProps.updID)});
				}
			}, fnERROR);
		});
	}
}