/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Command = {
	initialized 	: false,
	path			: {},
	
	editor			: null,
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
			alert(err.toString());
		}
	},
		
	init : function() {
		$("#dlgCommand").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.LABEL_OK,
					id		: "dlgCommand_btnExecute",
					click	: function() { Dialog.Command.execute(); }
				},
				{
					text	: i18n.LABEL_RESET,
					id		: "dlgCommand_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.Command.reset({clear : true}) }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgCommand_btnCache",
					click	: function() { Dialog.Command.openCache() }
				},
				{
					text	: i18n.LABEL_CANCEL,
					id		: "dlgCommand_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Command.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgCommand_query').css('height', 'calc(100% - 1.0em');
				}
			},	
		});	
	
		/////Cria o editor 
		this.editor	= new JSONEditor(document.getElementById('dlgCommand_query'), 	this.editorOptions, {});
		this.initialized 			= true;
	},
		
	
	getForCache : function() {
		return {
			body 	: Dialog.Command.editor.get(),
		};		
	},
	
	
	setFromCache : function(cache) {
		Dialog.Command.editor.set(cache.body ? cache.body : {});
	},
	
	
	reset : function(options) {
		if (options.query) {
			$("#dlgCommand_btnReset").hide();
			$("#dlgCommand_btnCache").hide();
			$("#dlgCommand_QueryID").val(options.query.id);

			Dialog.Command.setFromCache(options.query);
		} else {
			$("#dlgCommand_btnReset").show();
			$("#dlgCommand_btnCache").show();
			$("#dlgCommand_QueryID").val((new Date()).getTime());
			
			if (!options.clear) {
				Dialog.Command.setFromCache(Cache.Query.get("command.single",{ "body" : {"command" : "collection", "query" : "cmd"}}));
			} else {
				Dialog.Command.setFromCache({ "body" : {"command" : "collection", "query" : "cmd"}});
			}
		}
	},
		
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgCommand").dialog("option", "title", i18n.DLGCOMMAND_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database}));
		$("#dlgCommand").dialog("open");
	},
	
	
	openCache : function() {
		Dialog.Cache.open({cmd : "COMMAND", json : Dialog.Command.getForCache(), callback : Dialog.Command.setFromCache});
	},
	
	
	close : function() {
		$("#dlgCommand").dialog("close");
	},

	
	execute : function() {
		if (!Helper.JSON.isValid(Dialog.Command.editor.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGCOMMAND_QUERY)});
			return;
		}
		
		this.close();
		
		Spinner.open(i18n.SPN_LOADFINDRESULT.replace("##CMD##","COMMAND"));
		
		var opts = DBTabs.getQuery($("#dlgCommand_QueryID").val(), {
			query		: this.editor.get(),
			mongoCmd	: "COMMAND",
		});
		
		if (!opts.id) {
			opts.id		= $("#dlgCommand_QueryID").val();
			opts.path	= this.path;
		}
		
		DBTabs.setQuery(opts, function() {
			if (!Dialog.Command.options.query) {			
				Cache.Query.set("command.single", Dialog.Command.getForCache());				
			}
		});
	}
}