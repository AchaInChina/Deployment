/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Confirmation = {
	open : function(opts, fnConfirm, fnCancel) {
		var height = (opts.height ? opts.height : 165);
		
		$("#dlgConfirmation_Message").html(opts.message);
		$("#dlgConfirmation").dialog({
			resizable	: false,
			height		: height,
			dialogClass	: "dialogNoClose",			
			modal		: true,
			title		: (opts.title ? opts.title : i18n.LABEL_CONFIRMATION),
			buttons		: [
				{
					text: (opts.btnConfirm ? opts.btnConfirm : i18n.LABEL_CONFIRM),
					click: function() {
						$(this).dialog("close");
						if (fnConfirm) fnConfirm();
					}
				},
				{
					text: (opts.btnCancel ? opts.btnCancel : i18n.LABEL_CANCEL),
					click: function() {
						$(this).dialog("close");
						if (fnCancel) fnCancel();
					}
				}
			]
		});
		
		$("#dlgConfirmation span.ui-icon").css("margin-bottom",(height > 180 ? height - 140 : 40));
	}
};



Dialog.AlertSuccess = {
	open : function(opts, fnOk) {
		$("#dlgAlertSuccess_Message").html(opts.message).css("color","green");
		$("#dlgAlertSuccess").dialog({
			resizable	: false,
			height		: 160,
			dialogClass	: "dialogNoClose",
			modal		: true,
			title		: (opts.title ? opts.title : i18n.DLGALERTSUCCESS_TITLE),
			buttons		: [
				{
					text: (opts.btnOK ? opts.btnOK : i18n.LABEL_OK),
					click: function() {
						$(this).dialog("close");
						if (fnOk) fnOk();
					},
				},
			]
		});		
	}
};



Dialog.AlertError = {
	open : function(opts, fnOk) {
		$("#dlgAlertError_Message").html(opts.message).css("color","red");
		$("#dlgAlertError").dialog({
			resizable	: false,
			height		: 160,
			modal		: true,
			dialogClass	: "dialogNoClose",
			title		: (opts.title ? opts.title : i18n.DLGALERTERROR_TITLE),
			buttons		: [
       		   {
       			   text: (opts.btnOK ? opts.btnOK : i18n.LABEL_OK),
       			   click: function() {
       				   $(this).dialog("close");
       				   if (fnOk) fnOk();
       			   },
       		   },
  		   ]
		});		
	}
};


Dialog.AlertWarning = {
	open : function(opts, fnOk) {
		$("#dlgAlertWarning_Message").html(opts.message).css("color","red");
		$("#dlgAlertWarning").dialog({
			resizable	: false,
			height		: 160,
			modal		: true,
			dialogClass	: "dialogNoClose",
			title		: (opts.title ? opts.title : i18n.DLGALERTWARNING_TITLE),
			buttons		: [
       		   {
       			   text: (opts.btnOK ? opts.btnOK : i18n.LABEL_OK),
       			   click: function() {
       				   $(this).dialog("close");
       				   if (fnOk) fnOk();
       			   },
       		   },
  		   ]
		});		
	}
};



Dialog.CreateEntity = {
	initialized : false,
	
	init : function() {
		$("#dlgCreateEntity").dialog({
			autoOpen		: false,
			dialogClass		: "dialogNoClose",
			height			: 160,
			width			: 350,
			modal			: true,			
			buttons			:  [
				{
					text: i18n.DLGCREATEENTITY_BTNCREATE,
					id: "dlgCreateEntity_btnCreate",
					click: function() {
						($(this).dialog("option","onCreateClick"))();
					}
				},
				{
					text: i18n.DLGCREATEENTITY_BTNCANCEL,
					id: "dlgCreateEntity_btnCancel",
					click: function() {
						$(this).dialog("close");
					}
				},
			]
		});
		
		this.initialized = true;
	},
	
	open : function(opts) {
		if (!this.initialized) this.init();
		
		$("#dlgCreateEntity_Label").html(opts.label);
		$("#dlgCreateEntity_Name").val("");
		$("#dlgCreateEntity").dialog("option", "title", opts.title);
		$("#dlgCreateEntity").dialog("option", "onCreateClick", function() { opts.fnCreate(); $("#dlgCreateEntity").dialog("close");});
		$("#dlgCreateEntity").dialog("open");		
	}
};