/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Insert = {
	initialized 	: false,
	path			: {},
	
	editorBody		: null,
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
				alert(err.toString());
		}
	},
		
	init : function() {
		$("#dlgInsert").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgInsert_btnInsert",
					click	: function() { Dialog.Insert.execute() }
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgInsert_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.Insert.reset({clear : true}) }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgInsert_btnCache",
					click	: function() { Dialog.Insert.openCache() }
				},
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgInsert_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Insert.close(); }
				},				
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgInsert_insertQuery').css('height', 'calc(100% - 1.0em');
				}
						
			},	
		});	
	
		/////Cria o editor
		this.editorBody	= new JSONEditor(document.getElementById('dlgInsert_insertQuery'), 	this.editorOptions, {});
		this.initialized 	= true;
	},
		
	
	getForCache : function() {
		return {
			body 	: Dialog.Insert.editorBody.get(),
		};		
	},
	
	
	setFromCache : function(cache) {
		Dialog.Insert.editorBody.set(cache.body ? cache.body : {});
	},
	
	
	reset : function(options) {
		if (!options.clear) {
			this.setFromCache(Cache.Query.get("insert.single",{}));
		} else {
			this.setFromCache({});
		}
	},
		
	
	open : function(path, options) {
		options		= (options ? options : {});
		this.path	= path;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgInsert").dialog("option", "title", i18n.DLGINSERT_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgInsert").dialog("open");
	},
	
	
	openCache : function() {
		Dialog.Cache.open({cmd : "INSERT", json : Dialog.Insert.getForCache(), callback : this.setFromCache});
	},
	
	
	close : function() {
		$("#dlgInsert").dialog("close");
	},
	
	
	execute : function() {		
		var coll	= new Struct.Collection();

		if(!Helper.JSON.isValid(Dialog.Insert.editorBody.getText())){
			Dialog.AlertError.open({"message":i18n.ALERT_INVALID_FIELDVALUE.replace("##FIELD##",i18n.DLGINSERT_LABEL)});
			return;
		}
		
		this.close();
		
		Spinner.open(i18n.SPN_INSERTINGDOC);		
		coll.insert({
			path	: Dialog.Insert.path, 
			body	: Dialog.Insert.editorBody.get()
		}, function(result) {
			DBTree.refreshDatabase({"server":Dialog.Insert.path.server,"database":Dialog.Insert.path.database});
			Spinner.close();
			
			Cache.Query.set("insert.single", Dialog.Insert.getForCache());
			Dialog.AlertSuccess.open({message: i18n.ALERT_INSERTSUCCESS});
		}, function(error) {
			Spinner.close();
			
			Dialog.AlertError.open({message: i18n.ALERT_INSERTERROR});
		});
	}
}