/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Cache = {
	initialized 	: false,
		
	init : function() {
		$("#dlgCache").dialog({
			width			: 900,
			height			: 600,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.LABEL_BACK,
					id		: "dlgCache_btnBack",
					click	: function() { Dialog.Cache.close() }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				}
			},	
		});	
	
		
		$("#dlgCache_btnAdd").click(Dialog.Cache.addToCache);
		$("#dlgCache_queryList").delegate(".cacheItem","click",Dialog.Cache.clickItem);
		$("#dlgCache_queryList").delegate(".cacheItem","dblclick",function() { Dialog.Cache.setItem($(this))});
		$("#dlgCache_queryList").sortable({
			revert	: true,
			stop	: Dialog.Cache.saveToCache
		});

		$("#dlgCache_queryList").contextmenu({
			delegate: ".cacheItem",
			menu: "#cm_CacheItem",
			preventSelect : false,
			beforeOpen :function(event, ui) {
				$(".cacheItem").removeClass("cacheItemSelected");
				$(ui.target).addClass("cacheItemSelected");				
			},
			select : function(event, ui) {
				switch (ui.cmd) {
					case "set" : Dialog.Cache.setItem($(ui.target)); break;
					case "remove" : Dialog.Cache.removeItem($(ui.target)); break;
				}
			}
		});
		
		
		/////Cria o editor 
		this.initialized 	= true;
	},

	
	loadFromCache : function() {
		return Cache.Query.get(Dialog.Cache.options.cmd.toLowerCase()+".multi", []);
	},
	
	
	saveToCache : function() {
		var cp = [];
		
		$("#dlgCache_queryList div").each(function() {
			cp.push(JSON.parse($(this).html()));
		});
		
		Cache.Query.set(Dialog.Cache.options.cmd.toLowerCase()+".multi",cp);
	},
	
	getCacheItem : function(str) {
		return '<div class="cacheItem">'+str+'</div>'
	},
	
	addToCache : function() {
		if ($("#dlgCache_current").html() == "") return;
		
		if ($("#dlgCache_queryList").html().indexOf($("#dlgCache_current").html()) >= 0) {
			alert("Ja existe");
			return;
		} 
		
		$("#dlgCache_queryList").append(Dialog.Cache.getCacheItem($("#dlgCache_current").html()));
		$("#dlgCache_current").html("");
		
		Dialog.Cache.saveToCache();
	},

	
	clickItem : function() {
		$(".cacheItem").removeClass("cacheItemSelected");
		$(this).addClass("cacheItemSelected");
	},
	
	
	setItem : function(item) {
		Dialog.Cache.close();
		Dialog.Cache.options.callback(JSON.parse(item.html()));
	},

	
	removeItem : function(item) {
		item.remove();
		Dialog.Cache.saveToCache();
	},
	
	
	printCached : function(cp) {
		$("#dlgCache_queryList").html("");
		
		for(var i in cp) {
			$("#dlgCache_queryList").append(Dialog.Cache.getCacheItem(JSON.stringify(cp[i])));
		}
	},
	
	reset : function(options) {
		$("#dlgCache_currentLabel").html(i18n.DLGCACHE_CURRENT.replaceList({"##COMMAND##" : options.cmd}));		
		$("#dlgCache_current").html(JSON.stringify(options.json));

		this.printCached(this.loadFromCache());
	},
	
	
	
	open : function(options) {
		options			= (options ? options : {});
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgCache").dialog("option", "title", i18n.DLGCACHE_TITLE.replaceList({"##COMMAND##" : options.cmd}));
		$("#dlgCache").dialog("open");
	},
	
	
	close : function() {
		$("#dlgCache").dialog("close");
	},
}