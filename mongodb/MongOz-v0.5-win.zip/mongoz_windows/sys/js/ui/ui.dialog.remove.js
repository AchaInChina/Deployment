/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Remove = {
	initialized 	: false,
	path			: {},
	
	editorQuery		: null,
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
				alert(err.toString());
		}
	},
		
	init : function() {
		$("#dlgRemove").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgRemove_btnRemove",
					click	: function() { Dialog.Remove.execute(); }
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgRemove_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.Remove.reset({clear : true}) }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgRemove_btnCache",
					click	: function() { Dialog.Remove.openCache() }
				},
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgRemove_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Remove.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgRemove_removeQuery').css('height', 'calc(100% - 1.0em');
				}
			},	
		});	
	
		/////Cria o editor
		this.editorQuery	= new JSONEditor(document.getElementById('dlgRemove_removeQuery'), 	this.editorOptions, {});
		this.initialized 	= true;
	},
		
	
	getForCache : function() {
		return {
			query 	: Dialog.Remove.editorQuery.get(),
		};		
	},
	
	
	setFromCache : function(cache) {
		Dialog.Remove.editorQuery.set(cache.query ? cache.query : {});
	},
	
	
	reset : function(options) {
		if (!options.clear) {
			this.setFromCache(Cache.Query.get("remove.single",{}));
		} else {
			this.setFromCache({});
		}
	},
		
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgRemove").dialog("option", "title", i18n.DLGREMOVECOLL_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgRemove").dialog("open");
	},

	
	openCache : function() {
		Dialog.Cache.open({cmd : "REMOVE", json : Dialog.Remove.getForCache(), callback : this.setFromCache});
	},
	
	
	close : function() {
		$("#dlgRemove").dialog("close");
	},

	
	execute : function() {		
		var coll	= new Struct.Collection();

		if(!Helper.JSON.isValid(Dialog.Remove.editorQuery.getText())){
			Dialog.AlertError.open({"message": i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGREMOVECOLL_LABELQUERY)});
			return;
		}

		
		var fnRemove = function() {
			Dialog.Remove.close();
			Spinner.open(i18n.SPN_REMOVINGDOC);		
			coll.remove({
				path	: Dialog.Remove.path, 
				query	: Dialog.Remove.editorQuery.get(),
			}, function(result) {
				DBTree.refreshDatabase({"server":Dialog.Remove.path.server,"database":Dialog.Remove.path.database});
				Spinner.close();
				
				Cache.Query.set("remove.single", Dialog.Remove.getForCache());
				Dialog.AlertSuccess.open({message: i18n.ALERT_REMOVESUCCESS});
			}, function(error) {
				Spinner.close();
				
				Dialog.AlertError.open({message: i18n.ALERT_REMOVEERROR});
			});
		}
		
		
		if (JSON.stringify(Dialog.Remove.editorQuery.get()) == "{}") {
			Dialog.Confirmation.open({message:i18n.ALERT_REMOVEALL, height:190},fnRemove);
		} else {
			fnRemove();
		}
	}
}