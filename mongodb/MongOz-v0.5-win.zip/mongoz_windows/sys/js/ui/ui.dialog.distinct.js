/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Distinct = {
	initialized 	: false,
	path			: {},
	editor			: null,
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
			alert(err.toString());
		}
	},
		
	init : function() {
		$("#dlgDistinct").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.LABEL_OK,
					id		: "dlgDistinct_btnExecute",
					click	: function() { Dialog.Distinct.execute() }
				},
				{
					text	: i18n.LABEL_RESET,
					id		: "dlgDistinct_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.Distinct.reset(Dialog.Distinct.options); }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgDistinct_btnCache",
					click	: function() { Dialog.Distinct.openCache() }
				},
				{
					text	: i18n.LABEL_CANCEL,
					id		: "dlgDistinct_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Distinct.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgDistinct_query').css('height', 'calc(100% - 1.0em');
				}
			},	
		});	
	
		/////Cria o editor 
		this.editor			= new JSONEditor(document.getElementById('dlgDistinct_query'), 	this.editorOptions, {});
		this.initialized 	= true;
	},
		
	
	getForCache : function() {
		return {
			query 	: Dialog.Distinct.editor.get(),
			field 	: $("#dlgDistinct_key").val(),
		};
	},
	
	
	setFromCache : function(cache) {
		$("#dlgDistinct_key").val(cache.field);
		Dialog.Distinct.editor.set(cache.query ? cache.query : {});
	},
	
	
	reset : function(options) {
		$("#dlgDistinct_QueryID").val((new Date()).getTime());
		
		if (options.query) {
			$("#dlgDistinct_QueryID").val(options.query.id);
			this.editor.set(options.query);
		} else if (!options.clear) {
			this.setFromCache(Cache.Query.get("distinct.single",{}));
		} else {
			this.setFromCache({});
		}
	},
		
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgDistinct").dialog("option", "title", i18n.DLGDISTINCT_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgDistinct").dialog("open");
	},
	
	
	openCache : function() {
		Dialog.Cache.open({cmd : "DISTINCT", json : Dialog.Distinct.getForCache(), callback : this.setFromCache});
	},
	
	
	close : function() {
		$("#dlgDistinct").dialog("close");
	},

	
	execute : function() {
		if (!$("#dlgDistinct_key").val()) {
			Dialog.AlertError.open({"message":i18n.ALERT_INVALID_FIELDVALUE.replace("##FIELD##",i18n.DLGDISTINCT_KEYLABEL)});
			return;							
		}
		
		if (!Helper.JSON.isValid(Dialog.Distinct.editor.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGDISTINCT_QUERY)});
			return;
		}
		
		this.close();
		
		Spinner.open(i18n.SPN_LOADFINDRESULT.replace("##CMD##","DISTINCT"));
		
		var opts = DBTabs.getQuery($("#dlgDistinct_QueryID").val(), {
			field		: $("#dlgDistinct_key").val(),
			query		: Dialog.Distinct.editor.get(),
			mongoCmd	: "DISTINCT",
		});

		if (!opts.id) {
			opts.id		= $("#dlgDistinct_QueryID").val();
			opts.path	= Dialog.Distinct.path;
		}
		
		DBTabs.setQuery(opts, function() {
			if (!Dialog.Distinct.options.query) {
				Cache.Query.set("distinct.single", Dialog.Distinct.getForCache());
			}
		});
	}
}