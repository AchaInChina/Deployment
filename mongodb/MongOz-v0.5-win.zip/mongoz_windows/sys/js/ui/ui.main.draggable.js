/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

$(window).load(function(){
	$("#dividerDB").draggable({
	    axis		: 'x', 
	    containment	: 'parent',
	    helper		: 'clone', 
	    drag		: function (event, ui) { 
			var cDBWidth	= $("#containerDB").width();
			var cDBHeight	= $("#containerDB").height();
			
			if (ui.offset.left > 200 && ui.offset.left < cDBWidth - 200) {
				$("#containerButtons").width(ui.offset.left + 5);
				$("#databaseList").width(ui.offset.left);
				$("#databaseOper").width(cDBWidth - ui.offset.left - 8);
				if ($("#databaseList").height() != cDBHeight -50) $("#databaseList").height($("#containerDB").height()-50);
			}
	    },
	    stop		: function (event, ui) {
	    	window.localStorage.setItem("panels.containerDB.width",$("#containerDB").width());
	    	window.localStorage.setItem("panels.containerButtons.width",$("#containerButtons").width());
	    	window.localStorage.setItem("panels.databaseList.width",$("#databaseList").width());
	    	window.localStorage.setItem("panels.databaseOper.width",$("#databaseOper").width());
	    }
	});


	$("#dividerMain").draggable({
	    axis		: 'y', 
	    containment	: 'parent',
	    helper		: 'clone', 
	    
	    drag		: function (event, ui) { 
			var cDBHeight = $("#containerMain").height();
			
			if (ui.offset.top > 20 && ui.offset.top < cDBHeight - 20) {
				$("#containerDB").height(ui.offset.top);
				$("#infoConsole").height(cDBHeight - ui.offset.top - 8);
				if ($("#databaseList").height() != $("#containerDB").height() -50) $("#databaseList").height($("#containerDB").height()-50);
				
				$(".databaseTabsContent").height($("#databaseOper").height() - $("#databaseTabs ul").height() -18);
				$("#databaseOper").width($("#containerDB").width() - $("#databaseList").width() - 8);
			}
	    },
	    stop		: function (event, ui) {
	    	window.localStorage.setItem("panels.containerDB.height",$("#containerDB").height());
	    	window.localStorage.setItem("panels.databaseList.height",$("#databaseList").height());
	    	window.localStorage.setItem("panels.databaseTabsContent.height",$(".databaseTabsContent").height());
	    	window.localStorage.setItem("panels.infoConsole.height",$("#infoConsole").height());
	    }
	});
	
	
	///// init
	var pVal = 0;
	
	pVal = window.localStorage.getItem("panels.containerDB.height");
	if (pVal) $("#containerDB").height(pVal);
	
	pVal = window.localStorage.getItem("panels.databaseList.height");
	if (pVal) $("#databaseList").height(pVal);
	
	pVal = window.localStorage.getItem("panels.infoConsole.height");
	if (pVal) $("#infoConsole").height(pVal);
	
	pVal = window.localStorage.getItem("panels.databaseTabsContent.height");
	if (pVal) $(".databaseTabsContent").height(pVal);	
	
	
	pVal = window.localStorage.getItem("panels.containerDB.width");
	if (pVal) $("#containerDB").width(pVal);
	
	pVal = window.localStorage.getItem("panels.containerButtons.width");
	if (pVal) $("#containerButtons").width(pVal);
	
	pVal = window.localStorage.getItem("panels.databaseList.width");
	if (pVal) $("#databaseList").width(pVal);
	
	pVal = window.localStorage.getItem("panels.databaseOper.width");
	if (pVal) $("#databaseOper").width(pVal);
});