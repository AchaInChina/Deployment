/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Find = {
	initialized 	: false,
	path			: {},
	
	editorQuery		: null,
	editorFields	: null,
	editorSort		: null,	
	editorOptions	: {
		mode: 'code',
		modes: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error: function (err) {
				alert(err.toString());
		}
	},
		
	init : function() {		
		$("#dlgFind").dialog({
			width			: 800,
			height			: 585,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgFind_btnFind",
					click	: function() { Dialog.Find.execute(); }
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					style	: "margin-left:20px",
					id		: "dlgFind_btnReset",
					click	: function() { Dialog.Find.reset({clear : true}) }
				},				
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgFind_btnCache",
					click	: function() { Dialog.Find.openCache() }
				},
				/*
				{
					text	: i18n.LABEL_HELP,
					id		: "dlgFind_btnHelp",
					click	: function() { Dialog.Find.close(); }
				},
				*/
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgFind_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Find.close(); }
				},
				
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    
				}
			},	
		});	
		
		/////Cria os editores e inputs
		this.editorQuery	= new JSONEditor(document.getElementById('findQuery'), 	this.editorOptions, {});
		this.editorFields	= new JSONEditor(document.getElementById('findFields'), this.editorOptions, {});
		this.editorSort		= new JSONEditor(document.getElementById('findSort'), 	this.editorOptions, {});
		$("#findSkip").spinner({ min: 0, max : 5000});
		$("#findLimit").spinner({ min: 0, max : 5000});
		this.initialized 		= true;
	},
		
	
	getForCache : function() {
		var findSkip	= $("#findSkip").spinner("value");
		var findLimit	= $("#findLimit").spinner("value");

		return {
			query 	: Dialog.Find.editorQuery.get(),
			fields	: Dialog.Find.editorFields.get(),
			sort	: Dialog.Find.editorSort.get(),
			skip	: (findSkip ? findSkip : undefined),
			limit	: (findLimit ? findLimit : undefined),			
		};		
	},
	
	
	setFromCache : function(cache) {
		Dialog.Find.editorQuery.set(cache.query ? cache.query : {});
		Dialog.Find.editorFields.set(cache.fields ? cache.fields : {});
		Dialog.Find.editorSort.set(cache.sort ? cache.sort : {});
		$("#findSkip").val(cache.skip ? cache.skip : 0);
		$("#findLimit").val(cache.limit ? cache.limit : 0);		
	},
	
	
	reset : function(options) {		
		if(options.query) {
			$("#dlgFind_btnReset").hide();
			$("#dlgFind_btnCache").hide();
			$("#dlgFind_QueryID").val(options.query.id);
			
			this.setFromCache(options.query);
		} else {
			$("#dlgFind_QueryID").val((new Date()).getTime());
			$("#dlgFind_btnReset").show();
			$("#dlgFind_btnCache").show();
			
			if (!options.clear) {
				this.setFromCache(Cache.Query.get("find.single",{}));
			} else {
				this.setFromCache({});
			}
		}
	},
		
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgFind").dialog("option", "title", i18n.DLGFIND_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgFind").dialog("open");
	},
	
	
	close : function() {
		$("#dlgFind").dialog("close");
	},
	
	openCache : function() {
		Dialog.Cache.open({cmd : "FIND", json : this.getForCache(), callback : this.setFromCache});
	},
	
	execute : function() {
		var findSkip	= $("#findSkip").spinner("value");
		var findLimit	= $("#findLimit").spinner("value");
		
		if(!Helper.JSON.isValid(Dialog.Find.editorQuery.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_INVALID_FIELDVALUE.replace("##FIELD##",i18n.DLGFIND_QUERY)});
			return;
		}
		
		if(!Helper.JSON.isValid(Dialog.Find.editorFields.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_INVALID_FIELDVALUE.replace("##FIELD##",i18n.DLGFIND_FIELDS)});
			return;
		}
		
		if(!Helper.JSON.isValid(Dialog.Find.editorSort.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_INVALID_FIELDVALUE.replace("##FIELD##",i18n.DLGFIND_SORT)});
			return;
		}
		
		this.close();
		Spinner.open(i18n.SPN_LOADFINDRESULT.replace("##CMD##","FIND"));
		
		var opts = DBTabs.getQuery($("#dlgFind_QueryID").val(), {
			query		: Dialog.Find.editorQuery.get(),
			fields		: Dialog.Find.editorFields.get(),
			sort		: Dialog.Find.editorSort.get(),
			skip		: (findSkip ? findSkip : undefined),
			limit		: (findLimit ? findLimit : undefined),
			mongoCmd	: "FIND",
		});

		if (!opts.id) {
			opts.id		= $("#dlgFind_QueryID").val();
			opts.path	= Dialog.Find.path;
		}
		
		DBTabs.setQuery(opts, function() {
			///// sets the cache only if it is a new FIND
			if (!Dialog.Find.options.query) {			
				Cache.Query.set("find.single", Dialog.Find.getForCache());
			}			
		});
	}
}