/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

DBTree = {
	serverTree	: null,
	cmMenuType	: "server",
	
	init : function() {
		$("#databaseTree").delegate(".treeItem", "click", function() {
        	$(".treeItem").removeClass("treeItemSelected");
        	$(this).addClass("treeItemSelected");			
		});
		
		
		$("#databaseTree").delegate(".treeHasChild", "dblclick", function() {
			$(this).next("ul:first").toggle();
			$("#databaseList").height($("#containerDB").height()-50);			
		});
		
		
		$("#databaseTree").contextmenu({
			delegate: ".treeItem",
			menu: "#cm_Server",
			preventSelect : true,
			beforeOpen: function(event, ui) {
				var target = $(ui.target);

				$(".treeItem").removeClass("treeItemSelected");

				target.addClass("treeItemSelected");

				if (target.hasClass("treeItemServer")) {
					DBTree.cmMenuType = "server";
					$(this).contextmenu("replaceMenu", "#cm_Server");
					
					var isExpanded = target.next("ul:first").is(":visible"); 
					$(this).contextmenu("showEntry", "expand", !isExpanded);
					$(this).contextmenu("showEntry", "retract", isExpanded);
				} else if (target.hasClass("treeItemDatabase")) {
					DBTree.cmMenuType = "database";
					$(this).contextmenu("replaceMenu", "#cm_Database")
					
					var isExpanded = target.next("ul:first").is(":visible"); 
					$(this).contextmenu("showEntry", "expand", !isExpanded);
					$(this).contextmenu("showEntry", "retract", isExpanded);
				} else if (target.hasClass("treeItemCollection")) {
					DBTree.cmMenuType = "collection";
					$(this).contextmenu("replaceMenu", "#cm_Collection")
				}
			},
			select : function(event, ui) {
				var target = $(".treeItemSelected");

				switch (DBTree.cmMenuType) {
					case "server" :
						switch (ui.cmd) {
							case "disconnect" :
								if (confirm(i18n.CONFIRM_SERVERDISCONNECT.replace("##SERVERNAME##",target.html()))) {
									Server.disconnect(target.data("path"), function() {
										DBTree.reopen();
									});
								}
							break;
	
							case "refresh" :
								DBTree.refreshServer(Struct.getPath(target.data("path")));
							break;
							
							case "expand" :
							case "retract" :
								target.next("ul:first").toggle();
							break;
	
							case "createdb":
								var path = target.data("path");
								
								Dialog.CreateEntity.open({
									label		: i18n.DLGCREATEENTITY_LABELDBNAME,
									title		: i18n.DLGCREATEENTITY_TITLECREATEDB,
									fnCreate	: function() {
										var entName = $("#dlgCreateEntity_Name").val();
										if (!entName || entName == "") {
											alert(i18n.DLGCREATEENTITY_DBNAMEEMPTY);
											return;
										}
										
										if (Helper.Array.indexOfName(Server.Connected[path].databases,entName) >= 0) {
											alert(i18n.DLGCREATEENTITY_DBEXISTS.replace("##DBNAME##",entName));
											return;										
										}
										
										path += "/"+entName;
										DBTree.createDatabase(Struct.getPath(path));
									}
								});
							break;
							
							default	: alert(i18n.STR_NOTIMPLEMENTED);
						}
	        		break;
	        		
	        		case "database" :
			        	switch (ui.cmd) {
			        		case "refresh"	:
			        			DBTree.refreshDatabase(Struct.getPath(target.data("path")));
			        		break;
			        		
							case "expand" :
							case "retract" :
								target.next("ul:first").toggle();
							break;
			        		
			        		case "createcoll" :
								var path = Struct.getPath(target.data("path"));
								
								Dialog.CreateEntity.open({
									label		: i18n.DLGCREATEENTITY_LABELCOLLNAME,
									title		: i18n.DLGCREATEENTITY_TITLECREATECOLL,
									fnCreate	: function() {
										var entName = $("#dlgCreateEntity_Name").val();
										if (!entName || entName == "") {
											alert(i18n.DLGCREATEENTITY_COLLNAMEEMPTY);
											return;
										}
										
										var srv = Server.Connected[path.server];
										var db	= Helper.Array.getByName(srv.databases,path.database);										
										if (Helper.Array.indexOfName(db.collections,entName) >= 0) {
											Dialog.AlertError.open({message: i18n.DLGCREATEENTITY_COLLEXISTS.replace("##COLLNAME##",entName)})
											return;
										}
										
										path.collection = entName;
										DBTree.createCollection(path);
									}
								});
			        		break;
			        		
							case "dropdb"	:
								var path = Struct.getPath(target.data("path"));
								Dialog.Confirmation.open({ message : i18n.CONFIRM_DROPDATABASE.replace("##DBNAME##",path.database)}, function() {
									Dialog.Confirmation.open({ message : i18n.DOUBLECONFIRM_DROPDATABASE.replace("##DBNAME##",path.database), height: 190}, function() {
										Spinner.open(i18n.SPN_DROPPINGDATABASE.replace("##DBNAME##",path.database));
										Server.Manager.dropEntity(path, function() {
											DBTree.refreshServer({server : path.server});
										})
									});
								});
							break;
							
							case "command" :
								Dialog.Command.open(Struct.getPath(target.data("path")));
							break;
							
							default			: alert(i18n.STR_NOTIMPLEMENTED);
			        	}
	        		break;
	        		
	        		case "collection" :
	        			switch (ui.cmd) {
							case "dropcoll" :
								var path = Struct.getPath(target.data("path"));
								Dialog.Confirmation.open({ message : i18n.CONFIRM_DROPCOLLECTION.replace("##COLLNAME##",path.collection) }, function() {
									Dialog.Confirmation.open({ message : i18n.DOUBLECONFIRM_DROPCOLLECTION.replace("##COLLNAME##",path.collection), height:190 }, function() {
										Spinner.open(i18n.SPN_DROPPINGCOLLECTION.replace("##COLLNAME##",path.collection));
										Server.Manager.dropEntity(path, function() {
											DBTree.refreshDatabase({server : path.server, database:path.database});
										});
									});
								});
							break;			        		

							case "find"			: Dialog.Find.open(Struct.getPath(target.data("path"))); break;
							case "findmodify"	: Dialog.FindModify.open(Struct.getPath(target.data("path"))); break;
							case "insert"		: Dialog.Insert.open(Struct.getPath(target.data("path"))); break;
							case "update"		: Dialog.Update.Collection.open(Struct.getPath(target.data("path"))); break;
							case "remove"		: Dialog.Remove.open(Struct.getPath(target.data("path"))); break;
							case "aggregate"	: Dialog.Aggregate.open(Struct.getPath(target.data("path"))); break;
							case "distinct"		: Dialog.Distinct.open(Struct.getPath(target.data("path"))); break;
	        				default				: alert(i18n.STR_NOTIMPLEMENTED);
	        			}
	        		break;
	        	}
	        }
		});		
	},
	
	reset : function() {
		
	},
	
	printCollections : function(server, db, collections) {
		var html = "";
		
		for (var i in collections) {
			var coll = collections[i];
			html += '<li class="serverli serverColl">';
			html += '<span data-path="'+server.id+'/'+db.name+'/'+coll.name+'" class="treeItem treeItemCollection">'+coll.name+' ('+coll.count+')</span>';					
			html += '</li>';
		}
				
		return html;
	},
	
	
	printDatabases : function(server, databases) {
		var html = "";
		
		for (var i in databases) {
			var db = databases[i];
			html += '<li class="serverli serverDB">';
			html += '<span data-path="'+server.id+'/'+db.name+'" class="treeItem treeItemDatabase treeHasChild">'+db.name+'</span>';	
			html += '<ul class="treeView treeFoldable">';
			
			html += this.printCollections(server, db, db.collections);
							
			html += '</ul>';
			html += '</li>';
		}
		
		return html;
	},
	
	
	printServers : function(conected) {
		var html = "";
		
		for (var id in conected) {
			var server = conected[id];
			
			html += '<li class="serverli serverSrv">';
			html += '<span data-path="'+server.id+'" class="treeItem treeItemServer treeHasChild">'+server.name + ' / ' + server.addr + ':'+server.port+'</span>';
			html += '<ul class="treeView treeFoldable">';
			
			html += this.printDatabases(server, server.databases);
			
			html += '</ul>';
			html += '</li>';
		}
		
		return html;
	},
	
	refreshServer : function(path) {
		Spinner.open(i18n.SPN_LOADINGSERVERINFO);
		Server.retrieveServerInfo(path, function(result) {
			$('.treeItemServer[data-path|="'+path.server+'"]').
				next("ul").
				html(DBTree.printDatabases(Server.Connected[path.server],result.databases));
			
			Spinner.close();
		}, function(result) {
			Spinner.close();
			alert("ERRO XXX");
		});
	},
	
	refreshDatabase : function(path) {
		Server.retrieveDatabaseInfo(path, function(result) {
			$('.treeItemDatabase[data-path|="'+Struct.pathToString(path)+'"]').
				next("ul").
				html(DBTree.printCollections(Server.Connected[path.server],result,result.collections));

			Spinner.close();
		}, function(result) {
			Spinner.close();
			alert("ERRO");
		});
	},
	
	createDatabase : function(path) {
		Spinner.open(i18n.SPN_CREATINGDATABASE.replace("##DBNAME##",path.database));
		Server.Manager.createEntity(path, function() {
			DBTree.refreshServer({server:path.server});
		}, function() {
			Spinner.close();
			alert("ERRO ZZ");
		});
	},
	
	createCollection : function(path) {
		Spinner.open(i18n.SPN_CREATINGCOLLECTION.replace("##COLLNAME##",path.collection));
		Server.Manager.createEntity(path, function() {
			DBTree.refreshDatabase({server:path.server, database:path.database});
		}, function() {
			Spinner.close();
			alert("ERRO");
		});
	},
	
	open : function() {
		var html = "";
		
		html += '<ul id="serverTree" class="treeView">';
		html += this.printServers(Server.Connected);
		html += '</ul>';
		
		$("#databaseTree").html(html);
		$("#containerMain").show();
	},
	
	reopen : function() {
		if (Server.connectedServers > 0) {
			DBTree.open();
		} else {
			$("#containerMain").hide();
			$("#databaseTree").html("");
			Dialog.Connection.open({showSettings:true});
		}
	}
};