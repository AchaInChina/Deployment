/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Update = {};

Dialog.Update.Collection = {
	initialized 	: false,
	path			: {},
	
	editorQuery		: null,
	editorBody		: null,
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
				alert(err.toString());
		}
	},
		
	init : function() {
		$("#dlgUpdateCollection").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgUpdateColl_btnUpdate",
					click	: function() { Dialog.Update.Collection.execute() }
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgUpdateColl_btnReset",
					style	: "margin-left:20px",

					click	: function() { Dialog.Update.Collection.reset({clear:true}) }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgUpdateColl_btnCache",
					click	: function() { Dialog.Update.Collection.openCache() }
				},
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgUpdateColl_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Update.Collection.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgUpadeteCollection_updateQuery').css('height', 'calc(100% - 1.0em');
				    $('#dlgUpadeteCollection_updateBody').css('height', 'calc(100% - 1.0em');
				}
			},
		});	
	
		/////Cria o editor 
		this.editorQuery	= new JSONEditor(document.getElementById('dlgUpadeteCollection_updateQuery'), 	this.editorOptions, {});
		this.editorBody		= new JSONEditor(document.getElementById('dlgUpadeteCollection_updateBody'), 	this.editorOptions, { "$set" : {}});
		this.initialized 	= true;
	},
		
	
	getForCache : function() {
		return {
			query	: Dialog.Update.Collection.editorQuery.get(),
			body 	: Dialog.Update.Collection.editorBody.get(),
			multi	: ($("#dlgUpdateCollection_multiCollection").prop("checked") ? true : false),
			upsert	: ($("#dlgUpdateCollection_upsertCollection").prop("checked") ? true : false),
			safe	: ($("#dlgUpdateCollection_safeCollection").prop("checked") ? true : false)			
		};
	},
	
	
	setFromCache : function(cache) {
		Dialog.Update.Collection.editorQuery.set(cache.query ? cache.query : {});
		Dialog.Update.Collection.editorBody.set(cache.body ? cache.body : {});
		$("#dlgUpdateCollection_multiCollection").prop("checked", cache.multi ? cache.multi : false);
		$("#dlgUpdateCollection_upsertCollection").prop("checked", cache.upsert ? cache.upsert : false);
		$("#dlgUpdateCollection_safeCollection").prop("checked", cache.safe ? cache.safe : false);			
	},
	
	
	reset : function(options) {
		if (!options.clear) {
			this.setFromCache(Cache.Query.get("update.single",{}));
		} else {
			this.setFromCache({});
		}
	},
		
	
	open : function(path, options) {
		options		= (options ? options : {});
		this.path	= path;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgUpdateCollection").dialog("option", "title", i18n.DLGUPDATECOLL_QUERY.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgUpdateCollection").dialog("open");
	},

	
	openCache : function() {
		Dialog.Cache.open({cmd : "UPDATE", json : Dialog.Update.Collection.getForCache(), callback : Dialog.Update.Collection.setFromCache});
	},
	
	
	close : function() {
		$("#dlgUpdateCollection").dialog("close");
	},

	
	execute : function() {		
		var coll	= new Struct.Collection();
		
		if (!Helper.JSON.isValid(Dialog.Update.Collection.editorQuery.getText())){
			Dialog.AlertError.open({"message": i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGUPDATECOLL_LABELQUERY)});
			return;
		}
		
		if (!Helper.JSON.isValid(Dialog.Update.Collection.editorBody.getText())){
			Dialog.AlertError.open({"message": i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGUPDATECOLL_LABELBODY)});
			return;
		}
		
		Dialog.Update.Collection.close();
		
		Spinner.open(i18n.SPN_UPDATINGDOC);
		coll.update({
			path	: Dialog.Update.Collection.path,
			query	: Dialog.Update.Collection.editorQuery.get(),
			body	: Dialog.Update.Collection.editorBody.get(),
			multi	: ($("#dlgUpdateCollection_multiCollection").prop("checked") ? true : false),
			upsert	: ($("#dlgUpdateCollection_upsertCollection").prop("checked") ? true : false),
			safe	: ($("#dlgUpdateCollection_safeCollection").prop("checked") ? true : false)
		}, function(result) {			
			Spinner.close();
			if (result.affected > 0) {
				Dialog.AlertSuccess.open({message: i18n.ALERT_UPDATESUCCESS});				
			} else {
				Dialog.AlertWarning.open({message: i18n.ALERT_UPDATEUNCHANGED});
			}
			Cache.Query.set("update.single", Dialog.Update.Collection.getForCache());
		}, function(error) {
			Spinner.close();	
			Dialog.AlertError.open({message: i18n.ALERT_UPDATEERROR});
		});
	}
}