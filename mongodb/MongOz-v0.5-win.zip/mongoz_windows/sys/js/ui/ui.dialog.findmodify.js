/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.FindModify = {
	initialized 	: false,
	path			: {},
	
	editorOptions	: {
		mode: 'code',
		modes: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error: function (err) {
			alert(err.toString());
		}
	},
	
	editorQuery		: null,
	editorField		: null,
	editorSort		: null,	
	editorUpdate	: null,	
		
	init : function() {		
		$("#dlgFindModify").dialog({
			width			: 800,
			height			: 655,
			autoOpen		: false,
			draggable		: false,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgFindModify_btnFind",
					click	: function() { Dialog.FindModify.execute() }
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgFindModify_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.FindModify.reset({clear : true}); }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgFindModify_btnCache",
					click	: function() { Dialog.FindModify.openCache() }
				},
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgFindModify_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.FindModify.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    
				}
			},	
		});	
		
		/////Cria os editores e inputs
		this.initialized 	= true;
		this.editorQuery	= new JSONEditor(document.getElementById('dlgFindModify_Query'), 	this.editorOptions, {});
		this.editorField	= new JSONEditor(document.getElementById('dlgFindModify_Fields'),	this.editorOptions, {});
		this.editorSort		= new JSONEditor(document.getElementById('dlgFindModify_Sort'),		this.editorOptions, {});
		this.editorUpdate	= new JSONEditor(document.getElementById('dlgFindModify_Update'), 	this.editorOptions, {});
		
		$("#dlgFindModify_Upsert").prop("checked", false);
		$("#dlgFindModify_Remove").prop("checked", false);
		$("#dlgFindModify_ReturnNew").prop("checked", false);
	},
		
	
	getForCache : function() {
		return {
			query		: Dialog.FindModify.editorQuery.get(),
			fields		: Dialog.FindModify.editorField.get(),
			sort		: Dialog.FindModify.editorSort.get(),
			update		: Dialog.FindModify.editorUpdate.get(),
			upsert		: $("#dlgFindModify_Upsert").prop("checked"),
			remove		: $("#dlgFindModify_Remove").prop("checked"),
			returnNew	: $("#dlgFindModify_ReturnNew").prop("checked"),
		};		
	},
	
	
	setFromCache : function(cache) {
		$("#dlgFindModify_Upsert").prop("checked", cache.upsert ? true : false);
		$("#dlgFindModify_Remove").prop("checked", cache.remove ? true : false);
		$("#dlgFindModify_ReturnNew").prop("checked", cache.returnNew ? true : false);
		
		Dialog.FindModify.editorQuery.set(cache.query ? cache.query : {});
		Dialog.FindModify.editorField.set(cache.fields ? cache.fields : {});
		Dialog.FindModify.editorSort.set(cache.sort ? cache.sort : {});
		Dialog.FindModify.editorUpdate.set(cache.update ? cache.update : {});
	},
	
	
	reset : function(options) {		
		if(options.query) {
			$("#dlgFindModify_btnReset").hide();
			$("#dlgFindModify_btnCache").hide();
			$("#dlgFindModify_QueryID").val(options.query.id);
			Dialog.FindModify.setFromCache(options.query);
		} else {
			$("#dlgFindModify_btnReset").show();
			$("#dlgFindModify_btnCache").show();
			$("#dlgFindModify_QueryID").val((new Date()).getTime());
			
			if (!options.clear) {
				Dialog.FindModify.setFromCache(Cache.Query.get("findmodify.single",{}));
			} else {
				Dialog.FindModify.setFromCache({});
			}
		}		
	},
		
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgFindModify").dialog("option", "title", i18n.DLGFINDMODIFY_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgFindModify").dialog("open");
	},

	
	openCache : function() {
		Dialog.Cache.open({cmd : "FINDMODIFY", json : Dialog.FindModify.getForCache(), callback : Dialog.FindModify.setFromCache});
	},
	
	
	close : function() {
		$("#dlgFindModify").dialog("close");
	},
	
	
	execute :  function() {		
		if(!Helper.JSON.isValid(Dialog.FindModify.editorQuery.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGFIND_QUERY)});
			return;
		}
		
		if(!Helper.JSON.isValid(Dialog.FindModify.editorField.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGFIND_FIELDS)});
			return;
		}
		
		if(!Helper.JSON.isValid(Dialog.FindModify.editorSort.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGFIND_SORT)});
			return;
		}
		
		if(!Helper.JSON.isValid(Dialog.FindModify.editorUpdate.getText())) {
			Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGUPDATECOLL_LABELBODY)});
			return;
		}
		
		
		this.close();
		Spinner.open(i18n.SPN_LOADFINDRESULT.replace("##CMD##","FIND & MODIFY"));
		
		var opts = DBTabs.getQuery($("#dlgFindModify_QueryID").val(), {
			query		: this.editorQuery.get(),
			fields		: this.editorField.get(),
			sort		: this.editorSort.get(),
			update		: this.editorUpdate.get(),
			upsert		: $("#dlgFindModify_Upsert").prop("checked"),
			remove		: $("#dlgFindModify_Remove").prop("checked"),
			returnNew	: $("#dlgFindModify_ReturnNew").prop("checked"),
			mongoCmd	: "FINDMODIFY",
		});

		if (!opts.id) {
			opts.id		= $("#dlgFindModify_QueryID").val();
			opts.path	= Dialog.FindModify.path;
		}
		
		DBTabs.setQuery(opts, function() {
			if (!Dialog.FindModify.options.query) {			
				Cache.Query.set("findmodify.single", Dialog.FindModify.getForCache());
			}
		});
	}
}