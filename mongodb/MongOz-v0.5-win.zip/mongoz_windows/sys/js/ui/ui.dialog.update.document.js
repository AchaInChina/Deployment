/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Update.Document = {
	initialized 	: false,
	optionsUpdate	: null,
	optionsEditor	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
				alert(err.toString());
		}
	},
	editorUpdateDocQuery	: null,
	
	isJsonString	: function(json){
		try {
			JSON.parse(json);
		} catch (e) {
			return false;
		}
			return true;
	},
		
	init : function() {
		$("#dlgUpdateDocument").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.DLGFIND_BTNEXECUTE,
					id		: "dlgUpdateDoc_btnUpdate",
					click	: function() {
						var updateBody	= Dialog.Update.Document.editorUpdateDocQuery.getText();
						
						if (!Dialog.Update.Document.isJsonString(updateBody)){
							Dialog.AlertError.open({"message": i18n.ALERT_CHECKJSON.replace("##FIELD##",i18n.DLGUPDATEDOC_LABELBODY)});
							return;
						}
						
						Dialog.Update.Document.close();
						Dialog.Update.Document.update(JSON.parse(updateBody));
					}
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgUpdateDoc_btnReset",
					click	: function() {
						Dialog.Update.Document.editorUpdateCollQuery.set({});
					}
				},
				{
					text	: i18n.DLGFIND_BTNCANCEL,
					id		: "dlgUpdateDoc_btnCancel",
					click	: function() {
						Dialog.Update.Document.close();
					}
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgUpdate_documentQuery').css('height', 'calc(100% - 1.0em');
				}
						
			},	
		});	
	
		/////Cria o editor 
		this.editorUpdateDocQuery	= new JSONEditor(document.getElementById('dlgUpdate_documentQuery'), 	this.optionsEditor, {});
		this.initialized 			= true;
	},
	
	
	reset : function(options) {
		this.optionsUpdate = options;
		Dialog.Update.Document.editorUpdateDocQuery.set(options.doc);
	},
		

	open : function(valueField, options) {
		if (!this.initialized) this.init();
		
		this.reset(options);
		
		$("#dlgUpdateDocument").dialog("option", "title", i18n.DLGUPDATEDOC_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection}));
		$("#dlgUpdateDocument").dialog("open");
	},
	
	
	close : function() {
		$("#dlgUpdateDocument").dialog("close");
	},

	
	update : function(body) {		
		var coll	= new Struct.Collection();
		
		Spinner.open(i18n.SPN_UPDATINGDOC);
		Spinner.close();

		coll.update({
			path	: Dialog.Update.Document.optionsUpdate.queryPath,
			query	: Dialog.Update.Document.optionsUpdate.docID,
			body	: body,
		}, function(result) {			
			Spinner.close();
			if (result.affected > 0) {
				DBTabs.execQuery(Dialog.Update.Document.optionsUpdate.queryID);				
				Dialog.AlertSuccess.open({message: i18n.ALERT_UPDATESUCCESS});				
			} else {
				Dialog.AlertWarning.open({message: i18n.ALERT_UPDATEUNCHANGED});
			}
		}, function(error) {
			Spinner.close();	
			Dialog.AlertError.open({message: i18n.ALERT_UPDATEERROR});
		});
	}
};