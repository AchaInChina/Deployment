/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Connection = {
	initialized : false,
	openOpts	: {},
	
	
	init : function() {
		$("#dlgConnection").dialog({
			width			: 480,
			height			: (window.innerHeight * 0.5),
			autoOpen		: false,
			dialogClass		: "dialogNoClose",
			draggable		: false,
			modal			: true,
			buttons			: [
   				{
					text: i18n.DLGCONNECTION_BTNCONNECT,
					id: "dlgConnection_btnConnect",
					click: function() {
						Dialog.Connection.connect();
					}
				},
   				{
					text: i18n.LABEL_SETTINGS,
					id: "dlgConnection_btnSettings",
					click: function() {
						Dialog.Connection.close();
						Dialog.Settings.open({openFrom : "start"});
					}
				},
				{
					text: i18n.DLGCONNECTION_BTNHOSTOPTIONS,
					id: "dlgConnection_btnHostOptions",
					click: function() {
						$("#dlgConnection_btnHostOptions").contextmenu("open", $("#dlgConnection_btnHostOptions"));
					}
				},
				{
					text: i18n.LABEL_CANCEL,
					id: "dlgConnection_btnCancel",
					click: function() {
						Dialog.Connection.close();
					}
				},
				{
					text: i18n.DLGCONNECTION_BTNSAVESERVER,
					id: "dlgConnection_btnNewHost_Save",
					click: function() {
						if (Dialog.Connection.saveHost()) Dialog.Connection.switchTo("list");							
					}
				},
				{
					text: i18n.LABEL_CANCEL,
					id: "dlgConnection_btnNewHost_Cancel",
					click: function() {
						Dialog.Connection.switchTo("list");
					}
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    $('#dlgConnection_Servers').css('height', 'calc(100% - 1.5em');
				    $('#dlgConnection_ServerList').css('height', 'calc(100% - 1.5em');
				    $('#dlgConnection_ServerNew').css('height', 'calc(100% - 1.5em');
				}
				
				Dialog.Connection.switchTo("list");
			},
		});	
		
		
		$("#dlgConnection_ServerNew_Port").spinner({ min: 1, max : 65535});
		
		$("#dlgConnection_ServerList").delegate(".dlgConnection_Item","click", function() {
        	$(".dlgConnection_Item").removeClass("dlgConnection_Item_Selected");
        	$(this).addClass("dlgConnection_Item_Selected");
		});
		
		
		$("#dlgConnection_ServerList").contextmenu({
			delegate: ".dlgConnection_Item",
			menu: "#cm_Host",
			preventSelect : true,
			beforeOpen: function(event, ui) {
				var target = $(ui.target);

	        	$(".dlgConnection_Item").removeClass("dlgConnection_Item_Selected");
				target.addClass("dlgConnection_Item_Selected");
			},
			select : function(event, ui) {
				var target		= $(".dlgConnection_Item_Selected");
				var selected	= target.data("id");
				
				switch (ui.cmd) {
					case "edit" :
						Dialog.Connection.editHost(selected);						
					break;
					
					case "remove" :
						if (confirm(i18n.DLGCONNECTION_DOREMOVESERVER.replace("##SERVERNAME##", Server.getByID(selected).name))) {
							Server.remove(selected);
							Dialog.Connection.reset({dontLoad:true});
						}						
					break;
				}
			}
		});
		
		
		$("#dlgConnection_btnHostOptions").contextmenu({
			menu: "#cm_HostOps",
			preventSelect : true,
			select : function(event, ui) {
				switch (ui.cmd) {
					case "new"		: Dialog.Connection.newHost(); break;
					case "import"	: Dialog.Connection.importHosts(); break;
					case "export"	: Dialog.Connection.exportHosts(); break;
				}
			}
		});
		
		
		this.initialized = true;
	},
	
	
	reset : function(options) {
		options = (options ? options : {});
		if (!options.dontLoad) Server.load();
		
		var hostList = "";
		for (var i in Server.list) {
			var host = Server.list[i];
			if (!Server.Connected[host.id]) {
				hostList += '<div class="dlgConnection_Item" data-id="'+host.id+'">'+host.name+'</div>';				
			}
		}
				
		$("#dlgConnection_ServerList").html(hostList);		
	},
		
	
	open : function(options) {
		options = (options ? options : {});
		this.openOpts = options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		
		$("#dlgConnection").dialog("open");
	},
	
	
	close : function() {
		$("#dlgConnection").dialog("close");
	},
	
	switchTo : function(view, title) {
		switch (view) {
			case "edit" :
				$('#dlgConnection_Servers').hide();		
				$('#dlgConnection_btnConnect').hide();
				$('#dlgConnection_btnSettings').hide();
				$("#dlgConnection_btnHostOptions").hide();
				$("#dlgConnection_btnCancel").hide();
				
				$('#dlgConnection_btnNewHost_Save').show();
				$('#dlgConnection_btnNewHost_Cancel').show();
				
				$("#dlgConnection_ServerNew legend").html(title);
				$('#dlgConnection_ServerNew').show();
			break;
			
			case "list" :
				$('#dlgConnection_ServerNew').hide();
				$('#dlgConnection_btnNewHost_Save').hide();
				$('#dlgConnection_btnNewHost_Cancel').hide();
				
				$('#dlgConnection_btnConnect').show();
				$("#dlgConnection_btnHostOptions").show();
				$('#dlgConnection_Servers').show();
				
				if (Dialog.Connection.openOpts.showCancel) {
					$("#dlgConnection_btnCancel").show();
				} else {
					$("#dlgConnection_btnCancel").hide();
				}
				
				if (Dialog.Connection.openOpts.showSettings) {
					$("#dlgConnection_btnSettings").show();
				} else {
					$("#dlgConnection_btnSettings").hide();
				}
			break;
		}
	},
	
	
	saveHost : function() {
		var hostName	= $("#dlgConnection_ServerNew_Name").val();
		var hostAddr	= $("#dlgConnection_ServerNew_Host").val();
		var hostPort	= $("#dlgConnection_ServerNew_Port").spinner("value");
		var selected	= $("#dlgConnection_ServerNew_EditID").val();
		
		if (!hostName || hostName == "") {
			alert(DLGCONNECTION_SERVERCANNOTBEEMPTY);
			return false;			
		}
		
		if (selected && selected != "") {
			Server.change(selected, {"name" : hostName, "addr" : hostAddr, "port": hostPort});
		} else {
			var hh = Server.hasServer(hostName.hashCode()); 
			if (hh.has) {
				alert(i18n.DLGCONNECTION_SERVERALREADYEXISTS.replace("##SERVERNAME##",hostName));
				return false;
			}
			Server.add({"name" : hostName, "addr" : hostAddr, "port": hostPort});
		}
		
		Dialog.Connection.reset({dontLoad: true});
		
		return true;
	},
	
	importHosts : function() {		
		var backEnd = new Backend.Control();
		
		backEnd.loadJSON({ callback : function(items) {
			var it		= null;
			var exists	= [];
			
			var fnImport = function() {
				for (var i in items) {
					it = items[i];
					if (exists.indexOf(it.name) >= 0) {
						Server.change(it.id, it);
					} else {
						Server.add(it);						
					}
				}
				
				Dialog.Connection.reset();
			};
			
			for (var i in items) {
				it = items[i];
				if (Server.getByID(it.id)) exists.push(it.name);
			}
			
			if (exists.length > 0) {
				Dialog.Confirmation.open({height: 180, message : i18n.ALERT_IMPORTREPLACE.replace("##HOSTS##",exists.toString())}, fnImport);
			} else {
				fnImport();
			}
			
		}, callbackError: function(error) {
			var errorMsg = "";
			
			switch (error.error) {
				case "00001" :
				case "00002" :
					errorMsg = i18n.STR_INVALIDJSONFILE;
				break;
				
				default :
					errorMsg = error.errorDesc;
			};
			
			Dialog.AlertError.open({message : i18n.ALERT_IMPORTERROR.replace("##MESSAGE##",errorMsg)});
		}});		
	},
	
	exportHosts : function() {
		var hostList = "[";
		for (var i in Server.list) {
			var host = Server.list[i];
			hostList += (i > 0 ? "," : "") + JSON.stringify(host);
		}
		hostList += "]";
		
		var backEnd = new Backend.Control();
		backEnd.saveJSON({
			fileName	: "mongoz.connectionsettings.json",
			fileBody	: hostList
		});
	},

	
	newHost : function() {
		$("#dlgConnection_ServerNew_EditID").val("");
		$("#dlgConnection_ServerNew_Name").val("");
		$("#dlgConnection_ServerNew_Host").val("127.0.0.1");
		$("#dlgConnection_ServerNew_Port").spinner("value",27017);
		$("#dlgConnection_ServerNew_Name").attr("disabled",false);
		
		Dialog.Connection.switchTo("edit",i18n.DLGCONNECTION_TITLESERVERNEW);
	},
	
	editHost : function(selected) {
		var host		= Server.getByID(selected);
				
		$("#dlgConnection_ServerNew_EditID").val(host.id);
		$("#dlgConnection_ServerNew_Name").val(host.name);
		$("#dlgConnection_ServerNew_Host").val(host.addr);
		$("#dlgConnection_ServerNew_Port").spinner("value",host.port);
		$("#dlgConnection_ServerNew_Name").attr("disabled",true);
		
		Dialog.Connection.switchTo("edit",i18n.DLGCONNECTION_TITLESERVEREDIT);
	},
	
	connect : function() {		
		var id	= $(".dlgConnection_Item_Selected").data("id");
		if (!id) {
			Dialog.AlertWarning.open({message: i18n.ALERT_SELECTHOST});
			return;
		}
		
		var srv = Server.getByID(id);
				
		Dialog.Connection.close();
		Spinner.open(i18n.SPN_CONNECTING.replace("##SERVERNAME##",srv.name));
		Server.connect(srv, function() {
			DBTree.open();
			Spinner.close();
		}, function() {
			Spinner.close();
			Dialog.AlertError.open({ message : i18n.PROC_ERRORCONNECTINGSERVER.replace("##SERVERNAME##",srv.name) }, function() {
				Dialog.Connection.open(Dialog.Connection.openOpts);
			});
		});
	}
}