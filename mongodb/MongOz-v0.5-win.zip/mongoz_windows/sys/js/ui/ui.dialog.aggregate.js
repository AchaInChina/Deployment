/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Aggregate = {
	initialized 	: false,
	path			: null,	
	editor			: null,	
	editorOptions	: {
		mode	: 'code',
		modes	: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
		error	: function (err) {
			alert(err.toString());
		}
	},
	stageOptions	: null,
	validOperators	: ["$group","$limit","$match","$project","$redact","$skip","$sort","$unwind","$goNear"],
	
	
	
	init : function() {
		this.initialized = true;
		
		$("#dlgAggregate").dialog({
			width			: 800,
			height			: 510,
			autoOpen		: false,
			draggable		: true,
			modal			: true,
			buttons			: [
				{
					text	: i18n.LABEL_OK,
					id		: "dlgAggregate_btnExecute",
					click	: function() { Dialog.Aggregate.execute(); }
				},
				{
					text	: i18n.DLGAGGREGATE_BTNSAVE,
					id		: "dlgAggregate_btnSaveQuery",
					click	: function() {
						if (Helper.JSON.isValid(Dialog.Aggregate.editor.getText())) {
							Dialog.Aggregate.saveItem();
						} else {
							Dialog.AlertError.open({"message":i18n.ALERT_CHECKJSON.replace("##FIELD##",Dialog.Aggregate.stageOptions.operator)});
						}
					}
				},
				{
					text	: i18n.DLGAGGREGATE_BTNDISCARD,
					id		: "dlgAggregate_btnDiscardQuery",
					click	: function() {
						Dialog.Aggregate.changeView({ view : "list"});
					}
				},
				{
					text	: i18n.DLGFIND_BTNRESET,
					id		: "dlgAggregate_btnReset",
					style	: "margin-left:20px",
					click	: function() { Dialog.Aggregate.reset({clear : true}); }
				},
				{
					text	: i18n.LABEL_CACHE,
					id		: "dlgAggregate_btnCache",
					click	: function() { Dialog.Aggregate.openCache() }
				},
				{
					text	: i18n.LABEL_CANCEL,
					id		: "dlgAggregate_btnCancel",
					style	: "margin-left:20px",
					click	: function() { Dialog.Aggregate.close(); }
				},
			],
			open: function( event, ui ) {
				if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
				    
				}
			},	
		});
	
		/////Cria o editor 
		this.editor	= new JSONEditor(document.getElementById('dlgAggregate_editor'), 	this.editorOptions, {});
		
		$("#dlgAggregate_Pipeline").sortable({ revert: true });
		$("#dlgAggregate_Pipeline").delegate(".aggregateStage", "dblclick", function() { Dialog.Aggregate.editItem($(this)); });		
		$(".aggregateOperator").click(function() { Dialog.Aggregate.newItem($(this).html()); });
		
		$("#dlgAggregate_Pipeline").contextmenu({
			delegate: ".aggregateStage",
			menu: "#cm_AggregateStage",
			preventSelect : false,
			select : function(event, ui) {
				switch (ui.cmd) {
					case "update" : Dialog.Aggregate.editItem($(ui.target)); break;
					case "remove" : Dialog.Aggregate.removeItem($(ui.target)); break;
				}
			}
		});
	},
	
	
	
	changeView : function(op) {
		switch (op.view) {
			case "list" :
				$("#dlgAggregate_listFieldSet").show();
				$("#dlgAggregate_btnExecute").show();
				$("#dlgAggregate_btnReset").show();
				$("#dlgAggregate_btnCache").show();
				$("#dlgAggregate_btnCancel").show();
				
				$("#dlgAggregate_editorFieldSet").hide();
				$("#dlgAggregate_btnSaveQuery").hide();
				$("#dlgAggregate_btnDiscardQuery").hide();
			break;
			
			case "edit" :
				if (op.operator == i18n.DLGAGGREGATE_FULL) {
					$("#dlgAggregate_editorLegend").html(i18n.DLGAGGREGATE_WHOLEPIPELINE);
				} else {
					$("#dlgAggregate_editorLegend").html(i18n.DLGAGGREGATE_EDITORLABLE.replace("##OPNAME##",op.operator));
				}
				
				$("#dlgAggregate_listFieldSet").hide();
				$("#dlgAggregate_btnExecute").hide();
				$("#dlgAggregate_btnReset").hide();
				$("#dlgAggregate_btnCache").hide();
				$("#dlgAggregate_btnCancel").hide();
				
				$("#dlgAggregate_editorFieldSet").show();
				$("#dlgAggregate_btnSaveQuery").show();
				$("#dlgAggregate_btnDiscardQuery").show();
			break;
		}
	},
	
	
	
	checkOperator : function(name) {
		return this.validOperators.indexOf(name) >= 0;
	},
	
	
	
	checkOperatorStruct : function(name, body) {
		var opStruct = body[name];
		
		switch (name) {
			case "$limit" 	:
			case "$skip" 	:
				return Helper.Object.getObjectType(opStruct) == "integer";
			break;
			
			case "$sort" 	:
				if (Helper.Object.getObjectType(opStruct) != "object") return false;
				
				for (var sField in opStruct) {
					if (sField.charAt(0) == "$") return false;
					
					switch (opStruct[sField]) {
						case  1	:
						case -1 :
							return true;
						break;
												
						default :
							if (Helper.Object.getObjectType(opStruct[sField]) == "object") {
								return (JSON.stringify(opStruct[sField]) == JSON.stringify({ "$meta": "textScore" }));
							} else {
								return false;
							}
					}
				}
			break;
			
			case "$unwind" 	:
				return Helper.Object.getObjectType(opStruct) == "string" && opStruct.charAt(0) == '$';
			break;
			
			default 		:
				return true;
		}
	},
	
	
	
	setEditor : function(options) {
		var edObj		= options.obj;
		var edStruct	= null;
		
		
		if (options.operator == i18n.DLGAGGREGATE_FULL) {
			edObj = [];
			
			$(".aggregateStage").each(function() {
				edObj.push(JSON.parse($(this).html()));
			});
		} else {			
			switch (options.operator) {
				case "$group"	: edStruct = { "_id" : "", }; break;
				case "$limit"	: edStruct = 1; break;
				case "$match"	: edStruct = { "value" : "", }; break;
				case "$project"	: edStruct = { "value" : "", }; break;
				case "$redact"	: edStruct = {}; break;
				case "$skip"	: edStruct = 1; break;
				case "$sort"	: edStruct = { "FIELDNAME" : 1, }; break;
				case "$unwind"	: edStruct = "$FIELDPATH"; break;
				case "$goNear"	: edStruct = { near: { type: "Point", coordinates: [ 0.0 , 0.0 ] }, distanceField: "", maxDistance: 0, query: { }, includeLocs: "", num: 0, spherical: true }; break;
			}
			edObj = (edObj ? edObj[options.operator] : edStruct);			
		}
		
		this.stageOptions = options;	
		Dialog.Aggregate.editor.set(edObj);
	},
	
	
	getStages : function() {
		var aggregStages = "";
		
		$(".aggregateStage").each(function(){
			aggregStages += (aggregStages ? ", " : "") + $(this).html();
		});
		
		aggregStages = "[" + aggregStages + "]";
		
		return JSON.parse(aggregStages);
	},
		
	
	
	getForCache : function() {
		return {
			stages 	: Dialog.Aggregate.getStages(),
		};
	},
	
	
	
	setFromCache : function(cache) {
		for (var i in cache.stages) {
			$("#dlgAggregate_Pipeline").append('<div class="aggregateStage">'+JSON.stringify(cache.stages[i])+'</div>');
		} 
	},
	
	
	reset : function(options) {
		$("#dlgAggregate_QueryID").val((new Date()).getTime());
		$("#dlgAggregate_Pipeline").html("");
		Dialog.Aggregate.editor.set({});
		
		if (options.query) {
			$("#dlgAggregate_QueryID").val(options.query.id);
			this.editor.set(options.query);
		} else if (!options.clear) {
			this.setFromCache(Cache.Query.get("aggregate.single",{}));
		} else {
			this.setFromCache({});
		}
	},

	
	
	open : function(path, options) {
		options			= (options ? options : {});
		this.path		= path;
		this.options	= options;
		
		if (!this.initialized) this.init();
		this.reset(options);
		this.changeView({view:"list"});
		
		$("#dlgAggregate").dialog("option", "title", i18n.DLGAGGREGATE_TITLE.replaceList({"##SERVERNAME##" : Server.Connected[path.server].name, "##DBNAME##":path.database, "##COLLNAME##":path.collection}));
		$("#dlgAggregate").dialog("open");
	},
	

	
	openCache : function() {
		Dialog.Cache.open({cmd : "AGGREGATE", json : Dialog.Aggregate.getForCache(), callback : Dialog.Aggregate.setFromCache});
	},
	
	
	
	close : function() {
		$("#dlgAggregate").dialog("close");
	},

	
	
	newItem : function(operator) {
		var options = {
			view		: "edit",
			isNew		: true,
			operator	: operator
		};
		
		this.changeView(options);
		this.setEditor(options);
	},
	
	
	
	editItem : function(target) {
		var stage	= JSON.parse(target.html());
		var sName	= Helper.Object.getFirstPropertyName(stage);
		var options = {
			view		: "edit",
			isNew		: false,
			operator	: sName,
			obj			: stage,
			target		: target
		};
		
		this.changeView(options);
		this.setEditor(options);	
	},

	
	
	saveItem : function() {
		var stage		= {};
		var stageStr	= "";
		
		if (this.stageOptions.operator == i18n.DLGAGGREGATE_FULL) {
			stage = this.editor.get();
			
			for (var i in stage) {
				var stageBody	= stage[i];
				var oName		= Helper.Object.getFirstPropertyName(stageBody);
				if (!this.checkOperator(oName)) {
					Dialog.AlertError.open({"message":i18n.ALERT_INVALID_AGGREGOPERATOR.replace("##OPERATOR##",oName)});					
					return;
				}

				if (!this.checkOperatorStruct(oName,stageBody)) {
					Dialog.AlertError.open({"message":i18n.ALERT_INVALID_AGGREGOPSTRUCT.replace("##OPERATOR##",oName)});					
					return;
				}
				
				stageStr += '<div class="aggregateStage">'+JSON.stringify(stage[i])+'</div>'
			}
			$("#dlgAggregate_Pipeline").html(stageStr);
		} else {
			stage		= {}; stage[this.stageOptions.operator] = this.editor.get();
			stageStr	= JSON.stringify(stage);
			
			if (!this.checkOperatorStruct(this.stageOptions.operator,stage)) {
				Dialog.AlertError.open({"message":i18n.ALERT_INVALID_AGGREGOPSTRUCT.replace("##OPERATOR##",this.stageOptions.operator)});					
				return;
			}
			
			if (this.stageOptions.target) {
				this.stageOptions.target.replaceWith('<div class="aggregateStage">'+stageStr+'</div>');
			} else {
				$("#dlgAggregate_Pipeline").append('<div class="aggregateStage">'+stageStr+'</div>');
			}
		}
		
		this.changeView({"view" : "list"});
	},
	
	
	
	removeItem : function(target) {
		if (Dialog.Confirmation.open({"message":i18n.ALERT_REMOVEAGGREGSTAGE.replace("##STAGE##",target.html())}, function(){
			target.remove();
		}));
	},
	
	
	
	execute : function() {
		this.close();
		
		Spinner.open(i18n.SPN_LOADFINDRESULT.replace("##CMD##","AGGREGATE"));
		
		
		var opts = DBTabs.getQuery($("#dlgAggregate_QueryID").val(), {
			stages		: Dialog.Aggregate.getStages(),
			mongoCmd	: "AGGREGATE",
		});

		if (!opts.id) {
			opts.id		= $("#dlgAggregate_QueryID").val();
			opts.path	= this.path;
		}
		
		DBTabs.setQuery(opts, function() {
			if (!Dialog.Aggregate.options.query) {
				Cache.Query.set("aggregate.single", Dialog.Aggregate.getForCache());
			}
		});
	}
};