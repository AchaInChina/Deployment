/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

DBTabs.FieldEditor = {
	options		: null,
	valueField	: null,
	valueType	: null,
		
	update : function(value) {
		var options = DBTabs.FieldEditor.options;
		
		Dialog.Confirmation.open({
			message: i18n.CONFIRM_UPDATEFIELD.replace("##FIELD##",options.updID)
		}, function() {
			var coll	= new Struct.Collection();
			var obj		= {};
			
			obj[options.updID] = value;
			
			Spinner.open(i18n.SPN_UPDATINGFIELD);

			coll.update({
				path	: options.queryPath,
				query	: options.docID,
				body	: {"$set" : obj}
			}, function(result) {
				if (result.affected == 1) {
					var valueStr = "";
					
					switch (DBTabs.FieldEditor.valueType) {
						case "boolean"	: valueStr = (value ? "true" : "false"); break;
						case "date" 	: valueStr = new Date(value["$date"]).dateFormat(i18n.FORMAT_DATETIME); break;
						case "double"	: valueStr = value.formatDouble(12,i18n.FORMAT_NUMBER_DECIMALSEP, i18n.FORMAT_NUMBER_THOUSANDSEP); break;						
						default			: valueStr = value;
					}
					
					DBTabs.setNode(options.updID, options.doc, value);
					DBTabs.FieldEditor.valueField.html(valueStr);
					Spinner.close();
					Dialog.AlertSuccess.open({ message : i18n.ALERT_DOCUPDATEFIELD_SUCCESS.replace("##FIELD##",options.updID)});						 
				} else {
					Spinner.close();
					Dialog.AlertWarning.open({ message : i18n.ALERT_DOCUPDATEFIELD_NOTSET.replace("##FIELD##",options.updID)});
				}
			}, function(error) {
				Spinner.close();
				Dialog.AlertError.open({ message : i18n.ALERT_DOCUPDATEFIELD_ERROR.replace("##FIELD##",options.updID)});
			});
		});			
	},
		
	String 	: {
		initialized : false,
		
		init : function() {
			this.initialized 	= true;
			$("#dlgFieldEditor_String").dialog({
				width			: 800,
				height			: 360,
				autoOpen		: false,
				draggable		: false,
				modal			: true,
				buttons			: [
					{
						text	: i18n.LABEL_OK,
						id		: "dlgUpdateField_btnOk",
						click	: function() {
							DBTabs.FieldEditor.String.close();
							DBTabs.FieldEditor.update($("#dlgFieldEditor_String textarea").val());
						}
					},
					{
						text	: i18n.LABEL_CANCEL,
						id		: "dlgUpdateField_btnCancel",
						click	: function() {
							DBTabs.FieldEditor.String.close();
						}
					}
				],
				open: function( event, ui ) {
					if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
					    
					}
				},	
			});	
		},
		
		open : function(valueField, options) {
			if (!this.initialized) this.init();
			
			DBTabs.FieldEditor.options		= options;
			DBTabs.FieldEditor.valueField	= valueField;
			DBTabs.FieldEditor.valueType	= "string";
			
			$("#dlgFieldEditor_String").dialog("option", "title", i18n.DLGFIELDUPDATE_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection, "##FIELD##":options.updID}));
			$("#dlgFieldEditor_String textarea").val(options.updVal);
			$("#dlgFieldEditor_String").dialog("open");
		},
		
		close : function() {
			$("#dlgFieldEditor_String").dialog("close");
		},
	},
	
	Date : {
		initialized : false,
		init : function() {
			$("#dlgFieldEditor_Date").dialog({
				width			: 400,
				height			: 180,
				autoOpen		: false,
				draggable		: false,
				modal			: true,
				title			: "teste",
				buttons			: [
					{
						text	: i18n.LABEL_OK,
						id		: "dlgUpdateFieldDate_btnOk",
						click	: function() {
							var date	= new Date.parseDate($("#dlgFieldEditor_DateField").val(),i18n.FORMAT_DATETIME);
							
							DBTabs.FieldEditor.Date.close();							
							DBTabs.FieldEditor.update({ "$date" : date.toJSON()});
						}
					},
					{
						text	: i18n.LABEL_CANCEL,
						id		: "dlgUpdateFieldDate_btnCancel",
						click	: function() {
							DBTabs.FieldEditor.Date.close();
						}
					}
				],
				open: function( event, ui ) {
					if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
						 $('#dlgFieldEditor_Date fieldset').css('height', 'calc(100% - 1.5em');
					}
				},	
			});
					
			$('#dlgFieldEditor_DateField').datetimepicker({ lang: i18n.getShortLang(), mask:true, format: i18n.FORMAT_DATETIME, formatDate : i18n.FORMAT_DATE});
			this.initialized 	= true;
		},
		
		close : function() {
			$("#dlgFieldEditor_Date").dialog("close");
		},
		
		open : function(valueField, options) {
			if (!this.initialized) this.init();
			
			DBTabs.FieldEditor.options		= options;
			DBTabs.FieldEditor.valueField	= valueField;
			DBTabs.FieldEditor.valueType	= "date";
				
			var title = i18n.DLGFIELDUPDATE_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection, "##FIELD##":options.updID});
			$("#dlgFieldEditor_Date").dialog("option", "title", title);
			$("#dlgFieldEditor_Date").prev().find(".ui-dialog-title").attr("title",title); // hint for the dialog title
									
			$("#dlgFieldEditor_DateField").datetimepicker({"value":new Date(options.updVal).dateFormat(i18n.FORMAT_DATETIME)});
			$("#dlgFieldEditor_Date").dialog("open");	
		}
	},
	
	Integer :{
		initialized : false,
		init : function() {
			this.initialized 	= true;
			$("#dlgFieldEditor_Integer").dialog({
				width			: 400,
				height			: 180,
				autoOpen		: false,
				draggable		: false,
				modal			: true,
				title			: "teste",
				buttons			: [
					{
						text	: i18n.LABEL_OK,
						id		: "dlgUpdateFieldInteger_btnOk",
						click	: function() {
							DBTabs.FieldEditor.Integer.close();
							DBTabs.FieldEditor.update($("#dlgFieldEditor_Integer input").spinner("value"));
						}
					},
					{
						text	: i18n.LABEL_CANCEL,
						id		: "dlgUpdateFieldInteger_btnCancel",
						click	: function() {
							DBTabs.FieldEditor.Integer.close();
						}
					}
				],
				open: function( event, ui ) {
					if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
					    $('#dlgFieldEditor_Integer fieldset').css('height', 'calc(100% - 1.5em');
					}
				},	
			});
			
			$("#dlgFieldEditor_Integer input").spinner();
		},
		
		open : function(valueField, options) {
			if (!this.initialized) this.init();
			
			DBTabs.FieldEditor.options		= options;
			DBTabs.FieldEditor.valueField	= valueField;
			DBTabs.FieldEditor.valueType	= "number";
			
			var title = i18n.DLGFIELDUPDATE_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection, "##FIELD##":options.updID});
			$("#dlgFieldEditor_Integer").dialog("option", "title", title);
			$("#dlgFieldEditor_Integer").prev().find(".ui-dialog-title").attr("title",title); // hint for the dialog title
						
			$("#dlgFieldEditor_Integer input").spinner("value",options.updVal);
			$("#dlgFieldEditor_Integer").dialog("open");
		},
		
		close : function() {
			$("#dlgFieldEditor_Integer").dialog("close");
		},
	
	},
	
	Double :{
		initialized : false,
		init : function() {
			this.initialized 	= true;
			$("#dlgFieldEditor_Double").dialog({
				width			: 400,
				height			: 180,
				autoOpen		: false,
				draggable		: false,
				modal			: true,
				title			: "teste",
				buttons			: [
					{
						text	: i18n.LABEL_OK,
						id		: "dlgUpdateFieldDouble_btnOk",
						click	: function() {
							var value = Number($("#dlgFieldEditor_Double input").autoNumeric("get"));
							DBTabs.FieldEditor.Double.close();
							DBTabs.FieldEditor.update(value);
						}
					},
					{
						text	: i18n.LABEL_CANCEL,
						id		: "dlgUpdateFieldDouble_btnCancel",
						click	: function() {
							DBTabs.FieldEditor.Double.close();
						}
					}
				],
				open: function( event, ui ) {
					if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
						$('#dlgFieldEditor_Double fieldset').css('height', 'calc(100% - 1.5em');
					}
				},	
			});
			
			$("#dlgFieldEditor_Double input").autoNumeric("init", {aSep : i18n.FORMAT_NUMBER_THOUSANDSEP, aDec: i18n.FORMAT_NUMBER_DECIMALSEP, mDec : 12});
		},
		
		open : function(valueField, options) {
			if (!this.initialized) this.init();
			
			DBTabs.FieldEditor.options		= options;
			DBTabs.FieldEditor.valueField	= valueField;
			DBTabs.FieldEditor.valueType	= "double";
			
			var title = i18n.DLGFIELDUPDATE_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection, "##FIELD##":options.updID});
			$("#dlgFieldEditor_Double").dialog("option", "title", title);
			$("#dlgFieldEditor_Double").prev().find(".ui-dialog-title").attr("title",title); // hint for the dialog title
						
			$("#dlgFieldEditor_Double input").autoNumeric("set",options.updVal);
			$("#dlgFieldEditor_Double").dialog("open");
		},
		
		close : function() {
			$("#dlgFieldEditor_Double").dialog("close");
		},
	},
	
	Boolean :{
		initialized : false,
		init : function() {
			this.initialized 	= true;
			$("#dlgFieldEditor_Boolean").dialog({
				width			: 400,
				height			: 180,
				autoOpen		: false,
				draggable		: false,
				modal			: true,
				title			: "teste",
				buttons			: [
					{
						text	: i18n.LABEL_OK,
						id		: "dlgUpdateFieldBoolean_btnOk",
						click	: function() {
							DBTabs.FieldEditor.Boolean.close();
							DBTabs.FieldEditor.update($("#dlgFieldEditor_Boolean_True").prop("checked"));
						}
					},
					{
						text	: i18n.LABEL_CANCEL,
						id		: "dlgUpdateFieldBoolean_btnCancel",
						click	: function() {
							DBTabs.FieldEditor.Boolean.close();
						}
					}
				],
				open: function( event, ui ) {
					if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
						$('#dlgFieldEditor_Boolean fieldset').css('height', 'calc(100% - 1.5em'); 
					}
				},	
			});
			
		},
		
		open : function(valueField, options) {
			if (!this.initialized) this.init();
			
			DBTabs.FieldEditor.options		= options;
			DBTabs.FieldEditor.valueField	= valueField;
			DBTabs.FieldEditor.valueType	= "boolean";
			
			var title = i18n.DLGFIELDUPDATE_TITLE.replaceList({"##SERVERNAME##" : Server.getByID(options.queryPath.server).name, "##DBNAME##":options.queryPath.database, "##COLLNAME##" :options.queryPath.collection, "##FIELD##":options.updID});
			$("#dlgFieldEditor_Boolean").dialog("option", "title", title);
			$("#dlgFieldEditor_Boolean").prev().find(".ui-dialog-title").attr("title",title); // hint for the dialog title

			$("#dlgFieldEditor_Boolean_True").prop("checked", options.updVal);
			$("#dlgFieldEditor_Boolean_False").prop("checked", !options.updVal);
			
			$("#dlgFieldEditor_Boolean").dialog("open");			
		},
		
		close : function() {
			$("#dlgFieldEditor_Boolean").dialog("close");
		},
	
	},
};
