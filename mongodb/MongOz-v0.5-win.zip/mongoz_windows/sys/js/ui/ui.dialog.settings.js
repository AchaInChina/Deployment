/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Dialog.Settings = {
	initialized : false,
	openedFrom	: null,
	
	init : function() {
		$("#dlgSettings").dialog({
			width			: 450,
			height			: (window.innerHeight * 0.5),
			autoOpen		: false,
			dialogClass		: "dialogNoClose",
			draggable		: false,
			modal			: true,
			buttons			: [
				{
					text: i18n.LABEL_CONFIRM,
					id: "dlgSettings_btnConfirm",
					click: function() {
						Dialog.Settings.save();
						Dialog.Settings.close();
					}
				},
				{
					text: i18n.LABEL_CANCEL,
					id: "dlgSettings_btnCancel",
					click: function() {
						Dialog.Settings.close();
					}
				},
			],
			open: function( event, ui ) {
			},	
		});
		
		this.initialized = true;
	},
	
	reset : function(options) {
		this.openedFrom = options.openFrom;

		var sHtml = '<option '+(i18n._langDescription[i18n.currentLang] ? "" : "selected" )+'>'+i18n.LABEL_SELECT+'</option>'; 
		for (var id in i18n._langDescription) {
			sHtml += '<option value="'+id+'" '+(id == i18n.currentLang ? "selected" : "")+'>'+i18n._langDescription[id]+'</option>';
		}		
		$("#dlgSettings_LangList").html(sHtml);
				
		$("#dlgSettings_VersionCheckON").prop("checked",window.localStorage.getItem("version.ignoreCheck") == "yes" ? true : false );
		
		
		sHtml = "";
		for (var name in LOG.LEVEL) {
			sHtml += '<option value="'+LOG.LEVEL[name]+'" '+(LOG.CURRENT == LOG.LEVEL[name] ? "selected" : "")+'>'+name+'</option>';
		}
		$("#dlgSettings_logList").html(sHtml);
	},
	
	open : function(options) {
		options = (options ? options : {});
		
		if (!this.initialized) this.init();
		this.reset(options);		
		
		$("#dlgSettings").dialog("open");
	},
	
	close : function() {
		$("#dlgSettings").dialog("close");
		this.returnTo();
	},
	
	returnTo : function() {
		switch (Dialog.Settings.openedFrom) {
			case "start": Dialog.Connection.open({showSettings:true}); break;
		}
	},
	
	save : function() {
		var refreshBrowser = false;
		
		var cLang = $("#dlgSettings_LangList").val();
		if (cLang && cLang != "" && cLang != i18n.currentLang) {
			i18n.setLanguage($("#dlgSettings_LangList").val());
			refreshBrowser = true;
		}
		window.localStorage.setItem("version.ignoreCheck",$("#dlgSettings_VersionCheckON").prop("checked") ? "yes" : "no");
		
		LOG.set($("#dlgSettings_logList").val(), true);		
		
		if (refreshBrowser) {
			Dialog.Confirmation.open({message : i18n.ALERT_REFRESHBROWSER, btnConfirm : i18n.LABEL_YES, btnCancel :i18n.LABEL_NO}, function() {
				window.location.reload();
			});
		}
	}
}