/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

var i18n = {
	currentLang : "",
	
	_files : [
		"js/i18n/app.##LANG##.js",
	],
	
	_availableLang : {
		"en"	: "en",
		"pt"	: "pt-BR",
		"pt-BR" : "pt-BR",		
	},
	
	_langDescription : {
		"en"	: "English",
		"pt-BR"	: "Português Brasileiro"
	},
	
	getShortLang : function() {
		return i18n.currentLang.split("-")[0];
	},
	
	getLanguage : function() {
		var lang = window.localStorage.getItem("userLanguage");
		
		if (!lang) {
			lang = navigator.language || navigator.userLanguage;			
			lang = i18n._availableLang[lang];
			lang = (lang ? lang : "en");
		} 
		
		i18n.currentLang = lang;
		
		return lang; 
	},
	
	setLanguage : function(lang) {
		i18n.currentLang = lang;
		window.localStorage.setItem("userLanguage",lang);
	},
	
	apply : function() {
		$(".i18n").each(function() { 
			$(this).html(i18n[$(this).data("i18n")]);
		});
		
		$(".i18nTitle").each(function() { 
			$(this).attr("title",i18n[$(this).data("i18n")]);
		});
	},
	
	load : function(files, success) {
		if (files.length == 0) {
			success();
			return;
		}
		
		var file = files.shift();
		
		$.getScript(file.replace("##LANG##",i18n.currentLang)).
			done(function() { i18n.load(files, success); }).
			fail(function(jqxhr, settings, exception) { i18n.load(files, success); });
	},
	
	init : function(success) {
		i18n.getLanguage();
		
		i18n.load(Helper.Array.clone(i18n._files), success);
	}
};