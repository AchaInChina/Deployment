$.extend(i18n, {
	FORMAT_DATE							: "d/m/Y",
	FORMAT_DATETIME						: "d/m/Y H:i:s",
	FORMAT_NUMBER_DECIMALSEP			: ",",
	FORMAT_NUMBER_THOUSANDSEP			: ".",
	
	VALUE_TRUE							: "Verdadeiro",
	VALUE_FALSE							: "Falso",
	
	
	BTN_CONNECTOTHERSERVER				: "Conectar Outro Servidor",
	BTN_SETTINGS						: "Configurações da Aplicação",
	BTN_ABOUT							: "Sobre MongOz",
	
	SPN_CONNECTING						: "Conectando Servidor ##SERVERNAME##",
	SPN_LOADINGMETADATA					: "Carregando Metadados...",
	SPN_LOADINGSERVERINFO				: "Carregando informações do servidor...",
	SPN_CREATINGDATABASE				: "Criando Database ##DBNAME##...",
	SPN_DROPPINGDATABASE				: "Excluindo Database ##DBNAME##...",
	SPN_CREATINGCOLLECTION				: "Criando Coleção ##COLLNAME##...",
	SPN_DROPPINGCOLLECTION				: "Excluindo Coleção ##COLLNAME##...",
	SPN_LOADFINDRESULT					: "Carregando Resultados ##CMD## ...",
	SPN_INSERTINGDOC					: "Inserindo Documento...",
	SPN_UPDATINGDOC						: "Atualizando Documento...",
	SPN_REMOVINGDOC						: "Removendo Documento...",
	SPN_UNSETTINGFIELD					: "Removendo Campo de Documento...",
	SPN_UPDATINGFIELD					: "Atualizando Campo de Documento...",
	
	LABEL_CACHE							: "Cache",
	LABEL_HELP							: "Ajuda",
	LABEL_NEW							: "Novo",
	LABEL_CANCEL						: "Cancelar",
	LABEL_CONFIRM						: "Confirmar",
	LABEL_CONFIRMATION					: "Confirmação",
	LABEL_SETTINGS						: "Configurações",
	LABEL_SELECT						: "Selecione",
	LABEL_OK							: "OK",
	LABEL_RESET							: "Resetar",
	LABEL_YES							: "Sim",
	LABEL_NO							: "Não",
	LABEL_BACK							: "Voltar",
	
	LABEL_FINDREFRESH					: "Recarregar Resultados",
	LABEL_FINDEDIT						: "Editar Critério de Seleçãoi & Recarregar Resultados",
	LABEL_FINDEXPORT					: "Exportar Resultados",
	
	DLGCACHE_TITLE						: "Cache de Parâmetros para ##COMMAND##",
	DLGCACHE_CURRENT					: "Parâmetros do comando atual",
	DLGCACHE_QUERYLIST					: "Parâmetros armazenados",
	DLGCACHE_BTNADD						: "Adicionar à Cache",
	
	DLGABOUT_TITLE						: "Sobre",
	DLGABOUT_DISCLAIMER_TITLE			: "TERMO DE RESPONSABILIDADE",
	DLGABOUT_DISCLAIMER_BODY			: 'Copyright [2014] [Fábio Lutz / Diego Neumann]<br/><br/>' +
										  'Licensed under the Apache License, Version 2.0 (the "License");<br/>' +
										  'you may not use this file except in compliance with the License.<br/>' +
										  'You may obtain a copy of the License at<br/><br/>' +
										  '&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.apache.org/licenses/LICENSE-2.0" target="_blank">http://www.apache.org/licenses/LICENSE-2.0</a><br/><br/>' +
										  'Unless required by applicable law or agreed to in writing, software<br/>'+
										  'distributed under the License is distributed on an "AS IS" BASIS,<br/>'+
										  'WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.<br/>'+
										  'See the License for the specific language governing permissions and<br/>'+
										  'limitations under the License.',
	DLGABOUT_APP_TITLE					: VERSION_TITLE+' - Cliente Desktop Gratuito para MongoDB',
	DLGABOUT_APP_BODY					: 'Desenvolvido por:<br>' +
										  '&nbsp;&nbsp;- Fábio Lutz : <a href="mailto:fabiolutz@yahoo.com">fabiolutz@yahoo.com</a><br/>'+
										  '&nbsp;&nbsp;- Diego Neumann : <a href="mailto:diego.neumann.drese@gmail.com">diego.neumann.drese@gmail.com</a><br/>'+
										  '<br/>'+
										  'Agradecimentos Especiais a:<br/>'+
										  '&nbsp;&nbsp;- Bruno Costa : Pela ajuda com gráficos, logos e ícones<br/>'+
										  '&nbsp;&nbsp;- Vanessa Medeiros : Pelo <i>launcher</i> para MacOSX<br/>'+
										  '<br/>'+
										  'Websites:<br/>'+
										  '&nbsp;&nbsp;- <a href="http://mongoz.sourceforge.net/" target="_blank">WebSite Oficial</a><br/>'+
										  '&nbsp;&nbsp;- <a href="http://sourceforge.net/projects/mongoz/" target="_blank">Sumário SourceForge</a><br/>',
	
	DLGALERTERROR_TITLE					: "Erro",
	DLGALERTSUCCESS_TITLE				: "Sucesso",
	DLGALERTWARNING_TITLE				: "Atenção",
	
	DLGCONNECTION_TITLE					: "Conexão MongoDB",
	DLGCONNECTION_TITLELIST				: "Servidores",
	DLGCONNECTION_TITLESERVERNEW		: "Novo Servidor",
	DLGCONNECTION_EDITSERVERNAME		: "Nome do Servidor",
	DLGCONNECTION_EDITSERVERADDR		: "Endereço",
	DLGCONNECTION_EDITSERVERPORT		: "Porta",
	DLGCONNECTION_BTNHOSTOPTIONS		: "Opções",	
	DLGCONNECTION_BTNCONNECT			: "Connectar",
	DLGCONNECTION_BTNSAVESERVER			: "Salvar",
	DLGCONNECTION_SERVERALREADYEXISTS	: 'Servidor "##SERVERNAME##" já existe!',
	DLGCONNECTION_SERVERCANNOTBEEMPTY	: 'Nome do servidor não pode ser vazio!',
	DLGCONNECTION_DOREMOVESERVER		: 'Remover servidor "##SERVERNAME##" ?',
	
	DLGSETTINGS_TITLE					: "Configurações da Aplicação",
	DLGSETTINGS_TITLELANG				: "Língua",
	DLGSETTINGS_VERSIONCHECKTITLE		: "Verificação de Versão - Uma vez ao dia",
	DLGSETTINGS_VERSIONCHECKOPTION		: "Ignorar verificação de nova versão",		
	DLGSETTINGS_LOGTITLE				: "Nível de log do Javascript",
	
	DLGCREATEENTITY_BTNCREATE			: "Criar",
	DLGCREATEENTITY_BTNCANCEL			: "Cancelar",
	DLGCREATEENTITY_TITLECREATEDB		: "Criar Database",
	DLGCREATEENTITY_LABELDBNAME			: "Nome do Database",
	DLGCREATEENTITY_DBNAMEEMPTY			: "Nome do Database Name não pode ser vazio!",
	DLGCREATEENTITY_DBEXISTS			: "Database '##DBNAME##' já existe!",
	
	DLGCREATEENTITY_TITLECREATECOLL		: "Criar Coleção",
	DLGCREATEENTITY_LABELCOLLNAME		: "Nome da Coleção",
	DLGCREATEENTITY_COLLNAMEEMPTY		: "Nome da Coleção não pode ser vazio!",
	DLGCREATEENTITY_COLLEXISTS			: "Coleção '##COLLNAME##' já existe!",
	
	DLGAGGREGATE_TITLE					: "AGGREGATE em \"##SERVERNAME##.##DBNAME##.##COLLNAME##\"",
	DLGAGGREGATE_WHOLEPIPELINE			: "Todo o Pipeline de Agregação",
	DLGAGGREGATE_FULL					: "TUDO",
	DLGAGGREGATE_BTNSAVE				: 'Salvar',
	DLGAGGREGATE_BTNDISCARD				: 'Descartar',
	DLGAGGREGATE_EDITORLABLE			: 'Operador ##OPNAME##',
	
	DLGDISTINCT_TITLE					: 'DISTINCT em "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGDISTINCT_KEYLABEL				: 'Campo',
	DLGDISTINCT_QUERY					: 'Critério de Seleção',
	
	DLGCOMMAND_TITLE					: 'COMANDO em "##SERVERNAME##.##DBNAME##"',
	DLGCOMMAND_QUERY					: 'JSON do Comando MongoDB',
	
	DLGFIND_TITLE						: "FIND em \"##SERVERNAME##.##DBNAME##.##COLLNAME##\"",
	DLGFIND_ERROR_CHECKQUERY			: "Verifique o campo Query e corrija o JSON!",
	DLGFIND_ERROR_CHECKFIELDS			: "Verifique o campo Fields e corrija o JSON!",
	DLGFIND_ERROR_CHECKSORT				: "Verifique o campo Sort e corrija o JSON!",
	DLGFIND_BTNEXECUTE					: "OK",
	DLGFIND_BTNCANCEL					: "Cancelar",
	DLGFIND_BTNRESET					: "Resetar",
	DLGFIND_QUERY						: "Seleção",
	DLGFIND_FIELDS						: "Campos",
	DLGFIND_SORT						: "Ordenação",
	DLGFIND_SKIP						: "Pular",
	DLGFIND_LIMIT						: "Limite",
	
	DLGFINDMODIFY_TITLE					: 'FIND & MODIFY em "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	
	DLGFIELDUPDATE_TITLE				: "ATUALIZAR Campo - ##SERVERNAME##.##DBNAME##.##COLLNAME## / ##FIELD##",
	DLGFIELDUPDATE_LABELTITLE			: "Valor a Setar",

	DLGUPDATEDOC_TITLE					: "Atualizar Documento - ##SERVERNAME##.##DBNAME##.##COLLNAME##",
	DLGUPDATEDOC_LABELBODY				: "Conteúdo do Documento",
	DLGERRORVALIDATE_QUERY				: "Verifique a query digitada",
	
	DLGINSERT_TITLE						: 'INSERIR em "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGINSERT_LABELBODY					: 'Conteúdo do Documento',

	DLGREMOVECOLL_TITLE					: 'REMOVER de "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGREMOVECOLL_LABELQUERY				: 'Critério de Seleção',
	
	DLGIUPDATECOLL_QUERY				: 'ALTERAR EM "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGUPDATECOLL_LABELQUERY			: "Critério de Seleção",
	DLGUPDATECOLL_LABELBODY				: "Conteúdo a Atualizar",


	DLGVERSION_TITLE					: "Alerta de Versão",
	DLGVERSION_BTNDOWNLOAD				: "Baixar Agora",
	DLGVERSION_BTNLATER					: "Depois",
		
	PROC_ERRORCONNECTINGSERVER			: 'ERRO conectando servidor "##SERVERNAME##"',
	PROC_ERRORCHECKINGSERVER			: 'ERRO Verificando estatus de conexão do servidor!\r\nÉ possível que o servidor já esteja conectado, então, é sugerido matar e reiniciar o processo MongOz Java',
	
	CM_HOSTEDIT							: "Editar",
	CM_HOSTREMOVE						: "Remover",
	CM_HOSTNEW							: "Novo Servidor",
	CM_HOSTSIMPORT						: "Importar Servidores",
	CM_HOSTSEXPORT						: "Exportar Servidores",
	
	CM_SERVERINFO						: "Informações do Servidor",
	CM_SERVERREFRESH					: "Recarregar",
	CM_SERVERCREATEDB					: "Criar novo DATABASE",
	CM_SERVERDISCONNECT					: "Desconectar Servidor",

	CM_DBEXPAND							: "Expandir Nó",
	CM_DBRETRACT						: "Fechar Nó",
	
	CM_DBINFO							: "Informações Database",
	CM_DBREFRESH						: "Recarregar",
	CM_CREATECOLL						: "Criar Collection",
	CM_DBDROP							: "DROP Database",
	
	CM_COLLINFO							: "Informações Collection",
	CM_COLLREFRESH						: "Recarregar",
	CM_DBCOMMAND						: "Comando",
	CM_COLLDROP							: "DROP Collection",
	CM_COLLCREATEINDEX					: "Criar Índice",
	CM_COLLFIND							: "Find",
	CM_COLLFINDMODIFY					: "Find & Modify",
	CM_COLLAGGREGATE					: "Aggregate",
	CM_COLLDISTINCT						: "Distinct",
	CM_COLLINSERT						: "Insert",
	CM_COLLUPDATE						: "Update",
	CM_COLLREMOVE						: "Remove",
	
	CM_DOCUPDATE						: "Update",
	CM_DOCREMOVE						: "Remove",
	CM_DOCSETVALUE						: "Setar Valor",
	CM_DOCUNSETFIELD					: "Remover Campo",

	CM_CACHESET							: "Setar este",
	CM_CACHEREMOVE						: "Remover",
	
	
	CONFIRM_SERVERDISCONNECT			: 'Tem certeza que quer desconectar do servidor "##SERVERNAME##"?',
	CONFIRM_DROPDATABASE				: 'Confirma a exclusão do database "##DBNAME##"?',
	DOUBLECONFIRM_DROPDATABASE			: 'Você REALMENTE TEM CERTEZA que quer excluir o database "##DBNAME##"?<br/><br/>APÓS A EXCLUSÃO NÃO HÁ COMO DESFAZÊ-LA!!',
	DOUBLECONFIRM_DROPCOLLECTION		: 'Você REALMENTE TEM CERTEZA que quer excluir a coleção "##COLLNAME##"?<br/><br/>APÓS A EXCLUSÃO NÃO HÁ COMO DESFAZÊ-LA!!',
	CONFIRM_DROPCOLLECTION				: 'Confirma a exclusão da coleção "##COLLNAME##"?',
	CONFIRM_REMOVEDOC					: "Confirma a remoção do documento selecionado ?",
	CONFIRM_REMOVEFIELD					: 'Comfirma a remoção do campo "##FIELD##"?',
	CONFIRM_UPDATEFIELD					: 'Confirma a atualização do campo "##FIELD##"?',
	
	ALERT_SELECTHOST					: "Selecione um servidor para conectar!",
	ALERT_REFRESHBROWSER				: "É necessário recarregar o browser para as alteração serem efetivadas! Fazer agora?",
	ALERT_INSERTSUCCESS					: "Documento inserido com SUCESSO!",
	ALERT_INSERTERROR					: 'ERRO Inserindo Documento!',
	ALERT_UPDATESUCCESS					: "Documento Atualiado com SUCESSO!",
	ALERT_UPDATEERROR					: "ERRRO Atualizando Documento!",
	ALERT_UPDATEUNCHANGED				: "NENHUM DOCUMENTO Foi Atualizado!",
	ALERT_DOCREMOVE_SUCCESS				: "Documento Removido com SUCESSO!",
	ALERT_DOCREMOVE_ERROR				: "ERRO Removendo Documento!",
	ALERT_DOCREMOVE_NOTREMOVED			: "Documento NÃO FOI REMOVIDO!",
	ALERT_DOCUNSETFIELD_SUCCESS			: 'Campo "##FIELD##" removido com SUCESSO!',
	ALERT_DOCUNSETFIELD_NOTUNSET		: 'Campo "##FIELD##" NÃO REMOVIDO!',
	ALERT_DOCUNSETFIELD_ERROR			: 'ERRO Removendo campo "##FIELD##"!',
	ALERT_DOCUPDATEFIELD_SUCCESS		: 'Campo "##FIELD##" Atualizado com SUCESSO!',
	ALERT_DOCUPDATEFIELD_NOTSET			: 'Campo "##FIELD##" NÃO FOI Atualizado!',
	ALERT_DOCUPDATEFIELD_ERROR			: 'ERRO Atualizando Campo "##FIELD##"!',
	ALERT_CHECKJSON						: 'Verifique o JSON para "##FIELD##"',
	ALERT_REMOVEALL						: 'Usar "{}" como "Critério de Seleção" <span style="color:red">REMOVERÁ TODOS OS DOCUMENTOS da coleção</span>!!<br/>Você REALMENTE tem certeza ??',
	ALERT_REMOVESUCCESS					: 'Operação de REMOÇÃO executada com SUCESSO!',
	ALERT_REMOVEERROR					: 'ERRO Executando operação de REMOÇÃO!',
	ALERT_IMPORTREPLACE					: 'Os Servidores:<br/>##HOSTS##<br/>serão SUBSTITUIDOS. Continuar ?',
	ALERT_IMPORTERROR					: 'Erro importando arquivo: ##MESSAGE##',
	ALERT_NEWRELEASE					: 'Nova Versão disponível para download:<br/>v##NEWVERSION## - ##NEWVERSIONNAME##<br/>Liberada em: ##NEWVERSIONDATE##',
	ALERT_CANNOTREMOVE_NOID				: 'IMPOSSÍVEL REMOVER: O documento foi carregado sem o campo "_id"',
	ALERT_CANNOTUPDATE_NOID				: 'IMPOSSÍVEL ATUALIZAR: O documento foi carregado sem o campo "_id"',
	ALERT_REMOVEAGGREGSTAGE				: 'Remover o estágio de agregação?<br/>##STAGE##',
	ALERT_INVALID_AGGREGOPERATOR		: 'Operador Inválido para AGGREGATION: ##OPERATOR##',
	ALERT_INVALID_AGGREGOPSTRUCT		: 'Estrutura Inválida para o Operador ##OPERATOR##',
	ALERT_INVALID_FIELDVALUE			: 'Valor inválido para "##FIELD##"',
	
	STR_UNKNOWSERVER					: "Servidor Desconhecido",
	STR_NOTIMPLEMENTED					: "A ser implementado!",
	STR_INVALIDJSONFILE					: "Arquivo JSON Inválido!",
	
	TABS_REMOVETAB						: "Remover Aba",
		
	LOG_RETRIEVESRVRINFO				: "Buscando informações do Servidor - Servidor:##SERVERNAME##",
	LOG_RETRIEVESRVRINFO_SUCCESS		: "SUCESSO Buscando informações do Servidor - Servidor:##SERVERNAME##",
	LOG_RETRIEVESRVRINFO_ERROR			: "ERRO Buscando informações do Servidor - Servidor:##SERVERNAME##, Mensagem:##ERRORMSG##",
	
	LOG_RETRIEVEDBINFO					: "Buscando informações do Database - Servidor:##SERVERNAME##, Database:##DBNAME##",
	LOG_RETRIEVEDBINFO_SUCCESS			: "SUCESSO Buscando informações do Database - Servidor:##SERVERNAME##, Database:##DBNAME##",
	LOG_RETRIEVEDBINFO_ERROR			: "ERRO Buscando informações do Database - Servidor:##SERVERNAME##, Database:##DBNAME##, Mensagem:##ERRORMSG##",
	LOG_RETRIEVEDBINFO_NOTFOUND			: "Database Não encontrado",

	LOG_RETRIEVECOLLINFO				: "Buscando Informações da Collection - Servidor:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##",
	LOG_RETRIEVECOLLINFO_SUCCESS		: "SUCESSO Buscando Informações da Collection - Servidor:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##",
	LOG_RETRIEVECOLLINFO_ERROR			: "ERRO Buscando Informações da Collection - Servidor:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##, Mensagem:##ERRORMSG##",
	LOG_RETRIEVECOLLINFO_NOTFOUND		: "Collection Não Encontrada",
	
	
	LOG_COMMAND_SUCCESS					: "SUCESSO Executando COMANDO em ##SERVER##.##DBNAME## -> Query: ##QUERY##",
	LOG_COMMAND_ERROR					: 'ERRO Executando COMANDO em ##SERVER##.##DBNAME## -> Erro:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_FIND_SUCCESS					: "SUCESSO Executando FIND em ##SERVER##.##DBNAME##.##COLLNAME## -> Documentos Encontrados: ##LOADED##, Seleção: ##QUERY##, Campos:##FIELDS##, Ordenação:##SORT##, Limite:##LIMIT##, Pular:##SKIP##",
	LOG_FIND_ERROR						: 'ERRO Executando FIND em ##SERVER##.##DBNAME##.##COLLNAME## -> Erro:"<span class="consoleLvlERROR">##MSG##</span>", Seleção: ##QUERY##, Campos:##FIELDS##, Ordenação:##SORT##, Limite:##LIMIT##, Pular:##SKIP##',

	LOG_FINDMODIFY_SUCCESS				: "SUCESSO Executando FIND&MODIFY em ##SERVER##.##DBNAME##.##COLLNAME## -> Query: ##QUERY##",
	LOG_FINDMODIFY_ERROR				: 'ERRO Executando FIND&MODIFY em ##SERVER##.##DBNAME##.##COLLNAME## -> Erro:"<span class="consoleLvlERROR">##MSG##</span>"',

	LOG_AGGREGATE_SUCCESS				: "SUCESSO Executando AGGREGGATE em ##SERVER##.##DBNAME##.##COLLNAME## -> Registros Carregados: ##LOADED##, Query: ##QUERY##",
	LOG_AGGREGATE_ERROR					: 'ERRO Executando AGGREGGATE em ##SERVER##.##DBNAME##.##COLLNAME## -> Erro:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_DISTINCT_SUCCESS				: "SUCESSO Executando DISTINCT em ##SERVER##.##DBNAME##.##COLLNAME## -> Registros Carregados: ##LOADED##, Campo: ##FIELD##, Query: ##QUERY##",
	LOG_DISTINCT_ERROR					: 'ERRO Executando DISTINCT em ##SERVER##.##DBNAME##.##COLLNAME## -> Erro:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_INSERT_SUCCESS					: "SUCESSO Inserindo documento em ##SERVER##.##DBNAME##.##COLLNAME##",
	LOG_INSERT_ERROR					: 'ERRO Inserindo documento em ##SERVER##.##DBNAME##.##COLLNAME## -> Mensagem Servidor:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_UPDATE_SUCCESS					: "SUCESSO Atualizando documento(s) em ##SERVER##.##DBNAME##.##COLLNAME## -> Documentos Atualizados:##CHANGED##, Seleção: ##QUERY##, Atualizar com:##SET##",
	LOG_UPDATE_UNCHANGED				: 'A operação não atualizou nenhum documento em ##SERVER##.##DBNAME##.##COLLNAME## -> Seleção: ##QUERY##, Atualizar com:##SET##',
	LOG_UPDATE_ERROR					: 'ERRO Atualizando documento(s) em ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>", Seleção: ##QUERY##, Atualizar com:##SET##',
	
	LOG_REMOVE_SUCCESS					: "SUCESSO Removendo documentos de ##SERVER##.##DBNAME##.##COLLNAME## -> Documentos Removidos: ##REMOVED##, Seleção: ##QUERY##",
	LOG_REMOVE_ERROR					: 'ERRO Removendo documentos de ##SERVER##.##DBNAME##.##COLLNAME## -> Mensagem Servidor:"<span class="consoleLvlERROR">##MSG##</span>", Seleção: ##QUERY##',
	
	LOG_FIELDUNSET_SUCCESS				: 'SUCESSO Removendo campo "##FIELD##" de ##SERVER##.##DBNAME##.##COLLNAME##',
	LOG_FIELDUNSET_UNCHANGED			: 'Campo "##FIELD##" em ##SERVER##.##DBNAME##.##COLLNAME## NÃO FOI REMOVIDO!',
	LOG_FIELDUNSET_ERROR				: 'ERRO Removendo campo "##FIELD##" de ##SERVER##.##DBNAME##.##COLLNAME## -> Mensagem Servidor:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_NOLIMIT							: "Ilimitado",	
});