$.extend(i18n, {
	FORMAT_DATE							: "m/d/Y",
	FORMAT_DATETIME						: "m/d/Y H:i:s",
	FORMAT_NUMBER_DECIMALSEP			: ".",
	FORMAT_NUMBER_THOUSANDSEP			: ",",
	
	VALUE_TRUE							: "True",
	VALUE_FALSE							: "False",
	
	
	BTN_CONNECTOTHERSERVER				: "Connect Another Server",
	BTN_SETTINGS						: "Application Settings",
	BTN_ABOUT							: "About MongOz",
	
	SPN_CONNECTING						: "Connecting Server ##SERVERNAME##",
	SPN_LOADINGMETADATA					: "Loading Metadata...",
	SPN_LOADINGSERVERINFO				: "Loading Server Info...",
	SPN_CREATINGDATABASE				: "Creating Database ##DBNAME##...", 
	SPN_DROPPINGDATABASE				: "Dropping Database ##DBNAME##...",
	SPN_CREATINGCOLLECTION				: "Creating Collection ##COLLNAME##...",
	SPN_DROPPINGCOLLECTION				: "Dropping Collection ##COLLNAME##...",
	SPN_LOADFINDRESULT					: "Loading ##CMD## Results...",
	SPN_INSERTINGDOC					: "Inserting Document...",
	SPN_UPDATINGDOC						: "Updating Document...",
	SPN_REMOVINGDOC						: "Removing Document...",
	SPN_UNSETTINGFIELD					: "Unsetting Document Field...",
	SPN_UPDATINGFIELD					: "Updating Field...",
	
	LABEL_CACHE							: "Cache",
	LABEL_HELP							: "Help",
	LABEL_NEW							: "New",
	LABEL_CANCEL						: "Cancel",
	LABEL_CONFIRM						: "Confirm",
	LABEL_CONFIRMATION					: "Confirmation",
	LABEL_SETTINGS						: "Settings",
	LABEL_SELECT						: "Select",
	LABEL_OK							: "OK",
	LABEL_RESET							: "Reset",
	LABEL_YES							: "Yes",
	LABEL_NO							: "No",
	LABEL_BACK							: "Back",
	
	LABEL_FINDREFRESH					: "Refresh Results",
	LABEL_FINDEDIT						: "Edit Query & Reload Results",
	LABEL_FINDEXPORT					: "Export Results",

	DLGCACHE_TITLE						: "Parameters Cache for ##COMMAND##",
	DLGCACHE_CURRENT					: "Parameters for the current command",
	DLGCACHE_QUERYLIST					: "Cached Parameters",
	DLGCACHE_BTNADD						: "Add To Cache",
	
	DLGABOUT_TITLE						: "About",
	DLGABOUT_DISCLAIMER_TITLE			: "DISCLAIMER",
	DLGABOUT_DISCLAIMER_BODY			: 'Copyright [2014] [Fábio Lutz / Diego Neumann]<br/><br/>' +
										  'Licensed under the Apache License, Version 2.0 (the "License");<br/>' +
										  'you may not use this file except in compliance with the License.<br/>' +
										  'You may obtain a copy of the License at<br/><br/>' +
										  '&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.apache.org/licenses/LICENSE-2.0" target="_blank">http://www.apache.org/licenses/LICENSE-2.0</a><br/><br/>' +
										  'Unless required by applicable law or agreed to in writing, software<br/>'+
										  'distributed under the License is distributed on an "AS IS" BASIS,<br/>'+
										  'WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.<br/>'+
										  'See the License for the specific language governing permissions and<br/>'+
										  'limitations under the License.',
	DLGABOUT_APP_TITLE					: VERSION_TITLE+' - Free MongoDB Desktop Client',
	DLGABOUT_APP_BODY					: 'Developed by:<br>' +
										  '&nbsp;&nbsp;- Fábio Lutz : <a href="mailto:fabiolutz@yahoo.com">fabiolutz@yahoo.com</a><br/>'+
										  '&nbsp;&nbsp;- Diego Neumann : <a href="mailto:diego.neumann.drese@gmail.com">diego.neumann.drese@gmail.com</a><br/>'+
										  '<br/>'+
										  'Special Thanks to:<br/>'+
										  '&nbsp;&nbsp;- Bruno Costa : For the support with grahics, logos and icons<br/>'+
										  '&nbsp;&nbsp;- Vanessa Medeiros : For the MacOSX launcher<br/>'+
										  '<br/>'+
										  'Websites:<br/>'+
										  '&nbsp;&nbsp;- <a href="http://mongoz.sourceforge.net/" target="_blank">Official WebSite</a><br/>'+
										  '&nbsp;&nbsp;- <a href="http://sourceforge.net/projects/mongoz/" target="_blank">SourceForge Summary</a><br/>',
	
	DLGALERTERROR_TITLE					: "Error",
	DLGALERTSUCCESS_TITLE				: "Success",
	DLGALERTWARNING_TITLE				: "Warning",
	
	DLGCONNECTION_TITLE					: "MongoDB Connection",
	DLGCONNECTION_TITLELIST				: "Servers",
	DLGCONNECTION_BTNSETTINGS			: "Settings",
	DLGCONNECTION_TITLESERVERNEW		: "New Server",
	DLGCONNECTION_EDITSERVERNAME		: "Server Name",
	DLGCONNECTION_EDITSERVERADDR		: "Address",
	DLGCONNECTION_EDITSERVERPORT		: "Port",
	DLGCONNECTION_BTNHOSTOPTIONS		: "Options",	
	DLGCONNECTION_BTNCONNECT			: "Connect",
	DLGCONNECTION_BTNSAVESERVER			: "Save",
	DLGCONNECTION_SERVERALREADYEXISTS	: 'Server "##SERVERNAME##" already exists!',
	DLGCONNECTION_SERVERCANNOTBEEMPTY	: 'Server Name cannot be emtpy!',
	DLGCONNECTION_DOREMOVESERVER		: 'Remove the Server "##SERVERNAME##" ?',
	
	DLGSETTINGS_TITLE					: "Application Settings",
	DLGSETTINGS_TITLELANG				: "Language",
	DLGSETTINGS_VERSIONCHECKTITLE		: "Version Check - Once a Day",
	DLGSETTINGS_VERSIONCHECKOPTION		: "Ignore version release checking",
	DLGSETTINGS_LOGTITLE				: "Javascript Log Level Settings",	
	
	DLGCREATEENTITY_BTNCREATE			: "Create",
	DLGCREATEENTITY_BTNCANCEL			: "Cancel",
	
	DLGCREATEENTITY_TITLECREATEDB		: "Create Database",
	DLGCREATEENTITY_LABELDBNAME			: "Database Name",
	DLGCREATEENTITY_DBNAMEEMPTY			: "Database Name cannot be empty!",
	DLGCREATEENTITY_DBEXISTS			: "Database '##DBNAME##' already exists!",
		
	DLGCREATEENTITY_TITLECREATECOLL		: "Create Collection",
	DLGCREATEENTITY_LABELCOLLNAME		: "Collection Name",
	DLGCREATEENTITY_COLLNAMEEMPTY		: "Collection Name cannot be empty!",
	DLGCREATEENTITY_COLLEXISTS			: "Collection '##COLLNAME##' already exists!",
	
	DLGAGGREGATE_TITLE					: 'AGGREGATE on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGAGGREGATE_WHOLEPIPELINE			: "Whole Aggregation Pipeline",
	DLGAGGREGATE_FULL					: "FULL",
	DLGAGGREGATE_BTNSAVE				: 'Save',
	DLGAGGREGATE_BTNDISCARD				: 'Discard',
	DLGAGGREGATE_EDITORLABLE			: 'Operator ##OPNAME##',
	
	DLGDISTINCT_TITLE					: 'DISTINCT on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGDISTINCT_KEYLABEL				: 'Field',
	DLGDISTINCT_QUERY					: 'Selection Criteria',
	
	DLGCOMMAND_TITLE					: 'COMMAND on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGCOMMAND_QUERY					: 'MongoDB JSON Command',
	
	DLGFIND_TITLE						: 'FIND on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGFIND_ERROR_CHECKQUERY			: 'Check the "Query" field and fix the JSON!',
	DLGFIND_ERROR_CHECKFIELDS			: 'Check the "Fields" field and fix the JSON!',
	DLGFIND_ERROR_CHECKSORT				: 'Check the "Sort" field and fix the JSON!',
	DLGFIND_BTNEXECUTE					: "OK",
	DLGFIND_BTNCANCEL					: "Cancel",
	DLGFIND_BTNRESET					: "Reset",
	DLGFIND_QUERY						: "Query",
	DLGFIND_FIELDS						: "Fields",
	DLGFIND_SORT						: "Sort",
	DLGFIND_SKIP						: "Skip",
	DLGFIND_LIMIT						: "Limit",
	
	DLGFINDMODIFY_TITLE					: 'FIND & MODIFY on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	
	DLGFIELDUPDATE_TITLE				: "UPDATE Field - ##SERVERNAME##.##DBNAME##.##COLLNAME## / ##FIELD##",
	DLGFIELDUPDATE_LABELTITLE			: "Value to Set",
	
	DLGUPDATEDOC_TITLE					: "UPDATE Document - ##SERVERNAME##.##DBNAME##.##COLLNAME##",
	DLGUPDATEDOC_LABELBODY				: "Document Body",
	
	DLGINSERT_TITLE						: 'INSERT on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGINSERT_LABELBODY					: 'Document Body',
	
	DLGREMOVECOLL_TITLE					: 'REMOVE from "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGREMOVECOLL_LABELQUERY			: 'Selection Query',
	
	DLGUPDATECOLL_QUERY					: 'UPDATE on "##SERVERNAME##.##DBNAME##.##COLLNAME##"',
	DLGUPDATECOLL_LABELQUERY			: "Selection Criteria",
	DLGUPDATECOLL_LABELBODY				: "Update Body",
	
	DLGVERSION_TITLE					: "Version Release",
	DLGVERSION_BTNDOWNLOAD				: "Download Now",
	DLGVERSION_BTNLATER					: "Later",
		
	PROC_ERRORCONNECTINGSERVER			: 'ERROR connecting server "##SERVERNAME##"',
	PROC_ERRORCHECKINGSERVER			: 'ERROR checking server connection status! \r\nIt is possible that some server is connected, so, it is suggested to shutdonw/kill MongOz Java process and start it again!',
	
	CM_HOSTEDIT							: "Edit",
	CM_HOSTREMOVE						: "Remove",
	CM_HOSTNEW							: "New Host",
	CM_HOSTSIMPORT						: "Import Hosts",
	CM_HOSTSEXPORT						: "Export Hosts",
	
	CM_SERVERINFO						: "Server Info",
	CM_SERVERREFRESH					: "Refresh",
	CM_SERVERCREATEDB					: "Create New DATABASE",
	CM_SERVERDISCONNECT					: "Disconnect Server",
	
	CM_DBEXPAND							: "Expand Node",
	CM_DBRETRACT						: "Retract Node",
	
	CM_DBINFO							: "Database Info",
	CM_DBREFRESH						: "Refresh",
	CM_DBCOMMAND						: "Command",
	CM_CREATECOLL						: "Create Collection",
	CM_DBDROP							: "DROP Database",
	
	CM_COLLINFO							: "Collection Info",
	CM_COLLREFRESH						: "Refresh",
	CM_COLLDROP							: "DROP Collection",
	CM_COLLCREATEINDEX					: "Create Index",
	CM_COLLFIND							: "Find",
	CM_COLLFINDMODIFY					: "Find & Modify",
	CM_COLLAGGREGATE					: "Aggregate",
	CM_COLLDISTINCT						: "Distinct",
	CM_COLLINSERT						: "Insert",
	CM_COLLUPDATE						: "Update",
	CM_COLLREMOVE						: "Remove",
	
	CM_DOCUPDATE						: "Update",
	CM_DOCREMOVE						: "Remove",
	CM_DOCSETVALUE						: "Set Value",
	CM_DOCUNSETFIELD					: "Unset Field",
	
	CM_CACHESET							: "Set this",
	CM_CACHEREMOVE						: "Remove",
	
	CONFIRM_SERVERDISCONNECT			: 'Are you sure to disconnect from "##SERVERNAME##"?',
	CONFIRM_DROPDATABASE				: 'Are you sure to drop the database "##DBNAME##"?',
	DOUBLECONFIRM_DROPDATABASE			: 'Are you REALLY SURE to drop the database "##DBNAME##"?<br/><br/>THERE IS NO UNDO AFTER DONE!!',
	
	CONFIRM_DROPCOLLECTION				: 'Are you sure to drop the collection "##COLLNAME##"?',
	DOUBLECONFIRM_DROPCOLLECTION		: 'Are you REALLY SURE to drop the collection "##COLLNAME##"?<br/><br/>THERE IS NO UNDO AFTER DONE!!',
	CONFIRM_REMOVEDOC					: "Are you sure to remove the selected document ?",
	CONFIRM_REMOVEFIELD					: 'Are you sure to unset the field "##FIELD##"?',
	CONFIRM_UPDATEFIELD					: 'Are you sure to update the field "##FIELD##"?',
	
	ALERT_SELECTHOST					: "Select a Server Host to connect!",
	ALERT_REFRESHBROWSER				: "It's necessary to refresh the browser for the changes to be effective!<br/>Do it now?",
	ALERT_INSERTSUCCESS					: "Document inserted SUCCESSFULLY!",
	ALERT_INSERTERROR					: 'ERROR Inserting Document!',
	ALERT_UPDATESUCCESS					: "Document Updated SUCCESSFULLY!",
	ALERT_UPDATEERROR					: "ERRROR Updating Document!",
	ALERT_UPDATEUNCHANGED				: "NONE DOCUMENT was updated!",
	ALERT_DOCREMOVE_SUCCESS				: "Document Removed SUCCESSFULLY!",
	ALERT_DOCREMOVE_ERROR				: "ERROR Removing Document!",
	ALERT_DOCREMOVE_NOTREMOVED			: "Document was NOT REMOVED!",
	ALERT_DOCUNSETFIELD_SUCCESS			: 'Field "##FIELD##" unset SUCCESSFULLY!',
	ALERT_DOCUNSETFIELD_NOTUNSET		: 'Field "##FIELD##" was NOT UNSET!',
	ALERT_DOCUNSETFIELD_ERROR			: 'ERROR Unsetting field "##FIELD##"!',
	ALERT_DOCUPDATEFIELD_SUCCESS		: 'Field "##FIELD##" SUCCESSFULLY updated!',
	ALERT_DOCUPDATEFIELD_NOTSET			: 'Field "##FIELD##" was NOT updated!',
	ALERT_DOCUPDATEFIELD_ERROR			: 'ERROR Updating field "##FIELD##"!',
	ALERT_CHECKJSON						: 'Check the JSON for "##FIELD##"',
	ALERT_REMOVEALL						: 'Using "{}" as "Selection Query" <span style="color:red">will REMOVE ALL THE DOCUMENTS in the collection</span>!!<br/>Are you REALLY sure ??',
	ALERT_REMOVESUCCESS					: 'REMOVE Operation executed SUCCESSFULLY!',
	ALERT_REMOVEERROR					: 'ERROR Executing REMOVE Operation!',
	ALERT_IMPORTREPLACE					: 'The Hosts:<br/>##HOSTS##<br/>will be REPLACED. Continue ?',
	ALERT_IMPORTERROR					: 'Error importing file: ##MESSAGE##',
	ALERT_NEWRELEASE					: 'New Version available for download:<br/>v##NEWVERSION## - ##NEWVERSIONNAME##<br/>Released: ##NEWVERSIONDATE##',
	ALERT_CANNOTREMOVE_NOID				: 'IMPOSSIBLE TO REMOVE: The document was loaded with no "_id" field',
	ALERT_CANNOTUPDATE_NOID				: 'IMPOSSIBLE TO UPDATE: The document was loaded with no "_id" field',
	ALERT_REMOVEAGGREGSTAGE				: 'Remove the Aggregation stage ?<br/>##STAGE##',
	ALERT_INVALID_AGGREGOPERATOR		: 'Invalid Operator for AGGREGATION: ##OPERATOR##',
	ALERT_INVALID_AGGREGOPSTRUCT		: 'Invalid Structure for Operator ##OPERATOR##',
	ALERT_INVALID_FIELDVALUE			: 'Invalid value for "##FIELD##"',
	
	STR_UNKNOWSERVER					: "Unknown Server",
	STR_NOTIMPLEMENTED					: "To Be Implemented!",
	STR_INVALIDJSONFILE					: "Invalid JSON file!",
	
	TABS_REMOVETAB						: "Remove Tab",
		
	LOG_RETRIEVESRVRINFO				: "Retrieving Server Info - Server:##SERVERNAME##",
	LOG_RETRIEVESRVRINFO_SUCCESS		: "SUCCESS Retrieving ServerInfo - Server:##SERVERNAME##",
	LOG_RETRIEVESRVRINFO_ERROR			: "ERROR Retrieving Server Info - Server:##SERVERNAME##, Message:##ERRORMSG##",
	
	LOG_RETRIEVEDBINFO					: "Retrieving Database Info - Server:##SERVERNAME##, Database:##DBNAME##",
	LOG_RETRIEVEDBINFO_SUCCESS			: "SUCCESS Retrieving Database Info - Server:##SERVERNAME##, Database:##DBNAME##",
	LOG_RETRIEVEDBINFO_ERROR			: "ERROR Retrieving Database Info - Server:##SERVERNAME##, Database:##DBNAME##, Message:##ERRORMSG##",
	LOG_RETRIEVEDBINFO_NOTFOUND			: "Database NotFound",

	LOG_RETRIEVECOLLINFO				: "Retrieving Collection Info - Server:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##",
	LOG_RETRIEVECOLLINFO_SUCCESS		: "SUCCESS Retrieving Collection Info - Server:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##",
	LOG_RETRIEVECOLLINFO_ERROR			: "ERROR Retrieving Collection Info - Server:##SERVERNAME##, Database:##DBNAME##, Collection:##COLLNAME##, Message:##ERRORMSG##",
	LOG_RETRIEVECOLLINFO_NOTFOUND		: "Collection NotFound",
	
	
	LOG_COMMAND_SUCCESS					: "SUCCESS Executing COMMAND on ##SERVER##.##DBNAME## -> Query: ##QUERY##",
	LOG_COMMAND_ERROR					: 'ERROR Executing FIND on ##SERVER##.##DBNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_FIND_SUCCESS					: "SUCCESS Executing FIND on ##SERVER##.##DBNAME##.##COLLNAME## -> Matched Documents: ##LOADED##, Query: ##QUERY##, Fields:##FIELDS##, Sort:##SORT##, Limit:##LIMIT##, Skip:##SKIP##",
	LOG_FIND_ERROR						: 'ERROR Executing FIND on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>", Query: ##QUERY##, Fields:##FIELDS##, Sort:##SORT##, Limit:##LIMIT##, Skip:##SKIP##',
	
	LOG_FINDMODIFY_SUCCESS				: "SUCCESS Executing FIND&MODIFY on ##SERVER##.##DBNAME##.##COLLNAME## -> Query: ##QUERY##, Update: ##UPDATE##, [upsert=##UPSRT##, remove=##RMV##, returnNew=##RETNEW##]",
	LOG_FINDMODIFY_ERROR				: 'ERROR Executing FIND&MODIFY on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_AGGREGATE_SUCCESS				: "SUCCESS Executing AGGREGGATE on ##SERVER##.##DBNAME##.##COLLNAME## -> Record Amount: ##LOADED##, Query: ##QUERY##",
	LOG_AGGREGATE_ERROR					: 'ERROR Executing AGGREGGATE on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_DISTINCT_SUCCESS				: "SUCCESS Executing DISTINCT on ##SERVER##.##DBNAME##.##COLLNAME## -> Record Amount: ##LOADED##, Field: ##FIELD##,Query: ##QUERY##",
	LOG_DISTINCT_ERROR					: 'ERROR Executing DISTINCT on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_INSERT_SUCCESS					: "SUCCESS Inserting document on ##SERVER##.##DBNAME##.##COLLNAME##",
	LOG_INSERT_ERROR					: 'ERROR Inserting document on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_UPDATE_SUCCESS					: "SUCCESS Updating document on ##SERVER##.##DBNAME##.##COLLNAME## -> Update Amount: ##CHANGED##, Query: ##QUERY##, Set:##SET##",
	LOG_UPDATE_UNCHANGED				: 'The operation didn\'t change any document on ##SERVER##.##DBNAME##.##COLLNAME## -> Query: ##QUERY##, Set:##SET##',
	LOG_UPDATE_ERROR					: 'ERROR Updating document on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>", Query: ##QUERY##, Set:##SET##',
	
	LOG_REMOVE_SUCCESS					: "SUCCESS Removing documents from ##SERVER##.##DBNAME##.##COLLNAME## -> Removed Amount: ##REMOVED##, Query: ##QUERY##",
	LOG_REMOVE_ERROR					: 'ERROR Removing documents from ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>", Query: ##QUERY##',
	
	LOG_FIELDUNSET_SUCCESS				: 'SUCCESS Unsetting field "##FIELD##" on ##SERVER##.##DBNAME##.##COLLNAME##',
	LOG_FIELDUNSET_UNCHANGED			: 'Field "##FIELD##" on ##SERVER##.##DBNAME##.##COLLNAME## remains UNCHANGED',
	LOG_FIELDUNSET_ERROR				: 'ERROR Unsetting field "##FIELD##" on ##SERVER##.##DBNAME##.##COLLNAME## -> Server Message:"<span class="consoleLvlERROR">##MSG##</span>"',
	
	LOG_NOLIMIT							: "Unlimited",
});