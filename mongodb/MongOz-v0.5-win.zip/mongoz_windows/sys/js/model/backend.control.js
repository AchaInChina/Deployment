Backend.Control  = function(config) {
	this.inheritFrom = Backend.Comm;
	this.inheritFrom();

	var that = this;
		
	this.saveJSON = function(args) {
		var control = {
			context 	: "app",
			cmd			: "saveJSON",
			autoSubmit	: true,
			callback	: null,
		};
				
		var data	= {
			params : {
				fileName	: args.fileName,
				body		: args.fileBody				
			}
		};
		
		that.iframePost(control, data);
	};
	
	
	this.loadJSON = function(args) {
		var control = {
			context 		: "app",
			cmd				: "loadJSON",
			path			: (new Date()).getTime(),
			contentType		: "multipart/form-data",
			responseType	: "json",
			callback		: args.callback,
			callbackError	: args.callbackError
		};
				
		var data	= {
			body		:	'<input type="file" id="cmdFileField" name="fileBody" accept=".json" onChange="this.form.submit()" />',
			scriptAfter	:	'<script type="text/javascript">document.getElementById("cmdFileField").click();</script>'
		};
				
		that.iframePost(control, data);		
	}
};