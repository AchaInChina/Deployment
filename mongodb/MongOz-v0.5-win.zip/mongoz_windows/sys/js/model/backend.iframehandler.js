Backend.IFrameHandler = {
	responseType	: null,
	callback		: null,
	callbackError	: null,
	
	init : function() {
		$("#iframeCommand").load(Backend.IFrameHandler.loaded);
	},

	processJSON : function(body) {
		var json = "";
		
		try {
			json = JSON.parse(body);
		} catch (e) {
			json = {"success" : false, "error" : "00001"};
		}
		
		if (json.success) {
			if (Backend.IFrameHandler.callback) Backend.IFrameHandler.callback(json.result);			
		} else {
			if (Backend.IFrameHandler.callbackError) Backend.IFrameHandler.callbackError(json);
		}		
	},
	
	processGeneric : function(body) {
		if (Backend.IFrameHandler.callback) Backend.IFrameHandler.callback(body);
	},
	
	loaded : function() {
		var body = $($("#iframeCommand").contents().find('body')[0].innerHTML).html();
		
		switch (Backend.IFrameHandler.responseType) {
			case "json" : Backend.IFrameHandler.processJSON(body); break;
			default		: Backend.IFrameHandler.processGeneric(body);
			
		}
		
		Backend.IFrameHandler.clearCallback();
	},
	
	setCallback : function(responseType, cb, cbe) {
		Backend.IFrameHandler.responseType	= responseType;
		Backend.IFrameHandler.callback		= cb;
		Backend.IFrameHandler.callbackError	= cbe;		
	},
	
	clearCallback : function() {
		Backend.IFrameHandler.responseType	= null;
		Backend.IFrameHandler.callback		= null;
		Backend.IFrameHandler.callbackError = null;
	}	
};