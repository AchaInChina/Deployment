/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

var Struct		= {};

Struct.getPath = function(strPath) {
	var ar = (""+strPath).split("/");
	
	return {
		server		: ar[0],
		database	: ar[1],
		collection	: ar[2]
	}
};


Struct.pathToString = function(obj) {	
	var str = "";
	
	if (!obj || !obj.server) return str;	
	str += obj.server;
	
	if (!obj.database) return str;
	str += "/" + obj.database;
	
	if (!obj.collection) return str;
	str += "/" + obj.collection;
	
	return str;
};



Struct.Server = function(config) {
	this.inheritFrom = Backend.Comm;
	this.inheritFrom();
	
	var that = this;
	
	this.cmdRequest = function(args, success, fail) {
		var control = {
			method	: (args.method ? args.method : "GET"),
			context	: "db",
			cmd		: args.cmd,
			path	: Struct.pathToString(args.path)
		};
		
		var data	= {
			params	: args.params,
			body	: args.body
		};
		
		that.commRequest(control, data, success,fail);
	};
};



Struct.ServerManagement = function(config) {
	this.inheritFrom = Struct.Server;
	this.inheritFrom();

	var that = this;
	
	this.checkDBConnection = function(success, fail) {
		that.cmdRequest({cmd : "checkConnection"}, success, fail);
	};
	
	this.connectDB	= function(args, success, fail) {
		that.cmdRequest({cmd : "connect", path:{"server" : args.id}, params : {"options" : args}}, success, fail);
	};
	
	this.disconnectDB = function(id, success, fail) {
		that.cmdRequest({method: "DELETE", cmd : "disconnect", path:{"server" : id}}, success, fail);
	};
	
	this.retrieve_serverInfo = function(path, success, fail) {
		that.cmdRequest({cmd:"retrieveServerInfo", path:path}, success, fail);		
	};
	
	this.createEntity = function(path, success, fail) {
		that.cmdRequest({method: "POST", cmd:"createEntity", path:path}, success, fail);		
	};
	
	this.dropEntity = function(path, success, fail) {
		that.cmdRequest({method: "DELETE", cmd:"dropEntity", path:path}, success, fail);		
	};
};



Struct.DB = function(config) {
	this.inheritFrom = Struct.Server;
	this.inheritFrom();
	
	var that = this;

	this.getLOGPAR = function(opts, add) {
		add = (add ? add : {});
		return $.extend({
			"##SERVER##"	: Server.Connected[opts.path.server].name, 
			"##DBNAME##"	: opts.path.database
		}, add);
	};
	
	
	this.command = function(opts, success, fail) {
		LOG.debug("Collection.command("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= that.getLOGPAR(opts);	
		
		var args	= {
			method	: "PUT",
			cmd		: "command",
			path	: opts.path,
			body	: opts.query
		}
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_COMMAND_SUCCESS.replaceList($.extend(LOGPAR,{"##QUERY##":JSON.stringify(opts.query)})));
			if (success) success(result);
		}, function (error) {
			Server.log("error",i18n.LOG_COMMAND_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));			
			if (fail) fail(error);
		});		
	};
};



///// Collection
Struct.Collection = function(config) {
	this.inheritFrom = Struct.DB;
	this.inheritFrom();
	
	var that = this;
	
	this.getLOGPAR = function(opts, add) {
		add = (add ? add : {});
		return $.extend({
			"##SERVER##"	: Server.Connected[opts.path.server].name, 
			"##DBNAME##"	: opts.path.database, 
			"##COLLNAME##"	: opts.path.collection,
		}, add);
	};
	
	this.find	= function(opts, success, fail) {
		LOG.debug("Collection.find("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= $.extend(that.getLOGPAR(opts),{"##QUERY##" : JSON.stringify(opts.query), "##FIELDS##" : JSON.stringify(opts.fields), "##SORT##" : JSON.stringify(opts.sort), "##LIMIT##" : (opts.limit ? opts.limit : i18n.LOG_NOLIMIT), "##SKIP##" : (opts.skip ? opts.skip : 0)});	
		
		var args	= {
			method	: "GET",
			cmd		: "find",
			path	: opts.path,
			params	: {
				query		: (opts.query ? opts.query : {}),
				sort		: opts.sort,
				fields		: opts.fields,
				skip		: opts.skip, 
				batchSize	: opts.limit				
			}
		}
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_FIND_SUCCESS.replaceList($.extend(LOGPAR,{"##LOADED##":result.length})));
			if (success) success(result);
		}, function (error) {
			Server.log("error",i18n.LOG_FIND_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));			
			if (fail) fail(error);
		});
	};
	
	this.findModify	= function(opts, success, fail) {
		LOG.debug("Collection.findModify("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= that.getLOGPAR(opts);	
		
		var args	= {
			method	: "PUT",
			cmd		: "findModify",
			path	: opts.path,
			params	: {
				query		: (opts.query ? opts.query : {}),
				sort		: opts.sort,
				fields		: opts.fields,
				upsert		: opts.upsert,
				remove		: opts.remove,
				returnNew	: opts.returnNew,
			},
			body	: opts.update
		}
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_FINDMODIFY_SUCCESS.replaceList($.extend(LOGPAR,{"##QUERY##":JSON.stringify(opts.query), "##UPDATE##":JSON.stringify(opts.update), "##RMV##" : JSON.stringify(opts.remove), "##UPSRT##" : JSON.stringify(opts.upsert), "##RETNEW##" : JSON.stringify(opts.returnNew),})));
			if (success) success(result);
		}, function (error) {
			Server.log("error",i18n.LOG_FINDMODIFY_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));			
			if (fail) fail(error);
		});
	};
	
	
	this.aggregate = function(opts, success, fail) {
		LOG.debug("Collection.aggregate("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= that.getLOGPAR(opts);
		
		var args	= {
			method	: "GET",
			cmd		: "aggregate",
			path	: opts.path,
			params	: {
				stages	: (opts.stages ? opts.stages : []),
			}
		}
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_AGGREGATE_SUCCESS.replaceList($.extend(LOGPAR,{"##LOADED##":result.length, "##QUERY##":JSON.stringify(opts.stages)})));
			if (success) success(result);
		}, function (error) {
			Server.log("error",i18n.LOG_AGGREGATE_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));			
			if (fail) fail(error);
		});
	};
	
	
	this.distinct = function(opts, success, fail) {
		LOG.debug("Collection.distinct("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= that.getLOGPAR(opts);
		
		var args	= {
			method	: "GET",
			cmd		: "distinct",
			path	: opts.path,
			params	: {
				field : opts.field,
				query : opts.query
			}
		}
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_DISTINCT_SUCCESS.replaceList($.extend(LOGPAR,{"##LOADED##":result.length, "##FIELD##": opts.field, "##QUERY##":JSON.stringify(opts.query)})));
			if (success) success(result);
		}, function (error) {
			Server.log("error",i18n.LOG_DISTINCT_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));			
			if (fail) fail(error);
		});
	};

	
	this.insert	= function(opts, success, fail) {
		LOG.debug("Collection.insert("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= that.getLOGPAR(opts);
		
		var args	= {
			method	: "POST",
			cmd		: "insert",
			path	: opts.path,
			body	: opts.body
		};
		
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_INSERT_SUCCESS.replaceList(LOGPAR));
			if (success) success(result);
		}, function(error) {
			Server.log("error",i18n.LOG_INSERT_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));
			if (fail) fail(error);
		});
	};
	

	this.remove	= function(opts, success, fail) {
		LOG.debug("Collection.remove("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
		var LOGPAR	= $.extend(that.getLOGPAR(opts),{"##QUERY##" : JSON.stringify(opts.query)});
		
		var args	= {
			method	: "DELETE",
			cmd		: "remove",
			path	: opts.path,
			params	: {
				query : (opts.query ? opts.query : {"impossibleKey-012345" : "impossibleValue-098765"})
			}
		}
				
		that.cmdRequest(args, function(result) {
			Server.log("info",i18n.LOG_REMOVE_SUCCESS.replaceList($.extend(LOGPAR,{"##REMOVED##":result.affected})));
			if (success) success(result);
		}, function(error) {
			Server.log("error",i18n.LOG_REMOVE_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));
			if (fail) fail(error);
		});
	};
	
	
	this._update	= function(opts, success, fail) {
		LOG.debug("Collection.update("+JSON.stringify(opts)+")");
		opts		= (opts ? opts : {});
				
		var args = {
			method	: "PUT",
			cmd		: "update",
			path	: opts.path,
			body	: opts.body,
			params	: {
				query	: (opts.query ? opts.query : {}),
				multi	: (opts.multi ? opts.multi : false),
				upsert	: (opts.upsert ? opts.upsert : false),
				safe	: (opts.safe ? opts.safe : false),
			}
		};

		that.cmdRequest(args, success, fail);
	};

	this.update	= function(opts, success, fail) {
		var LOGPAR	= $.extend(that.getLOGPAR(opts),{"##QUERY##" : JSON.stringify(opts.query), "##SET##" : JSON.stringify(opts.body)});

		that._update(opts, function(result) {
			if (result.affected > 0) {
				Server.log("info",i18n.LOG_UPDATE_SUCCESS.replaceList($.extend(LOGPAR,{"##CHANGED##":result.affected})));
			} else {
				Server.log("warning",i18n.LOG_UPDATE_UNCHANGED.replaceList(LOGPAR));
			}
			if (success) success(result);			
		}, function(error) {
			Server.log("error",i18n.LOG_UPDATE_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));
			if (fail) fail(error);
		});
	};
	
	
	this.unsetField = function(args, success, fail) {
		var fieldID = {};
		var LOGPAR	= that.getLOGPAR(opts, {"##FIELD##"	: args.fieldID});

		fieldID[args.fieldID] = "";
		
		that._update({
			path	: args.path,
			query	: args.id,
			body	: { "$unset" : fieldID}
		}, function(result) {
			if (result.affected > 0) {
				Server.log("info",i18n.LOG_FIELDUNSET_SUCCESS.replaceList(LOGPAR));
			} else {
				Server.log("warning",i18n.LOG_FIELDUNSET_UNCHANGED.replaceList(LOGPAR));
			}
			if (success) success(result);
		}, function(error) {
			Server.log("error",i18n.LOG_FIELDUNSET_ERROR.replaceList($.extend(LOGPAR,{"##MSG##":error.serverMsg})));
			if (fail) fail(error);
		});
	}
};