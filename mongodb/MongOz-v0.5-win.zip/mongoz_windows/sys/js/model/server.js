/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Server = {
	Manager				: new Struct.ServerManagement(),
	Connected			: {},
	connectedServers	: 0,
	list				: [],
	keys				: {},
	
	sortFn	: function (a,b) {
		if (a.name.toUpperCase() < b.name.toUpperCase()) return -1;
		if (a.name.toUpperCase() > b.name.toUpperCase()) return 1;			
		return 0;
	},
	
	sortCollectionFn	: function (a,b) {
		if (a.name == "system.indexes") return 1;
		if (b.name == "system.indexes") return -1;
		
		if (a.name.toUpperCase() < b.name.toUpperCase()) return -1;
		if (a.name.toUpperCase() > b.name.toUpperCase()) return 1;			
		return 0;
	},
	
	log : function(level, str) {
		OpLog.log(level, str);
	},
	
	sortIndexes	: function(indexes) {
		indexes.sort(Server.sortFn);
	},
	
	sortCollections : function(collections) {
		collections.sort(Server.sortCollectionFn);
		
		///// sorts indexes
		for (var i in collections) {
			var coll = collections[i];
			Server.sortIndexes(coll.indexList);
		}		
	},
	
	sortDatabases : function(databases) {
		databases.sort(Server.sortFn);

		///// sorts collections
		for (var i in databases) {
			var collList = databases[i];
			Server.sortCollections(collList.collections);
		}		
	},
	
	sortConnected : function() {
		///// sorts servers
		var srt = [];
		for (var i in Server.Connected) {
			var conn = Server.Connected[i];			
			srt.push({name : conn.name, obj : conn});
		}
		
		srt.sort(Server.sortFn);
		Server.Connected = {};
		for (var i in srt) {
			var tmp = srt[i];
			Server.Connected[tmp.obj.id] = tmp.obj;
		}
		
		///// sorts databases
		for (var i in Server.Connected) {
			var conn = Server.Connected[i];
			Server.sortDatabases(conn.databases);
		}
	},
	
	rebuildIndex : function () {
		this.keys = {};
		
		for (var i in this.list) {
			var obj = this.list[i];
			this.keys[obj.id] = i;				
		}		
	},
	
	add	: function(server) {
		server.id = server.name.hashCode();
		Server.list.push(server);
		Server.list.sort(Server.sortFn);		
		Server.rebuildIndex();
		Server.save();
	},
	
	get	: function(index) {
		return Server.list[Number(index)];
	},
	
	getByID : function(id) {
		return Server.list[Server.keys[id]];
	},
	
	change : function(id, obj) {
		var index	= Server.keys[id];
		var old		= Server.list[index];
		
		Server.list[index] = $.extend(true, old, obj);
		Server.list.sort(Server.sortFn);
		Server.rebuildIndex();
		Server.save();
	},
	
	remove : function(id) {
		if (!id) return;
		
		var index = Server.keys[id];
		if (index >= 0) {
			Server.list.splice(index,1);
			Server.rebuildIndex();
			Server.save();			
		}
	},
	
	hasServer : function(id) {
		var sel = Server.keys[id];
		return ( sel >= 0 ? {has : true, pos : sel} : {has : false});
	},
	
	save	: function() {
		var str = JSON.stringify(Server.list);
		window.localStorage.setItem("serverConfig",str);
	},
	
	load	: function(success) {
		var str = window.localStorage.getItem("serverConfig");
		Server.list = JSON.parse(str);
		Server.list = (Server.list ? Server.list : []);
		Server.rebuildIndex();
		
		if (success) success();
	},
		
	init : function() {
		Server.load();
		
		Server.Manager.checkDBConnection(function(response) {
			if (response.status == "disconnected") {
				Spinner.close();
				Dialog.Connection.open({showSettings:true});
			} else {
				for(var i in response.serverID) {
					Server.Connected[response.serverID[i]] = $.extend(true,{},Server.getByID(response.serverID[i]));
				}	
				Server.retrieveConnectionInfo(function(){
					DBTree.open();
					Spinner.close();
				});
			}
		}, function(error) {
			alert(i18n.PROC_ERRORCHECKINGSERVER);
			Dialog.Connection.open();
		});		
	},
	
	
	retrieveCollectionInfo: function(path, success, fail) {
		var LOGPAR = {"##SERVERNAME##":Server.getByID(path.server).name, "##DBNAME##" : path.database, "##COLLNAME##":path.collection};
		Server.Manager.retrieve_serverInfo(path, function(response) {			
			var srv		= Server.Connected[path.server];
			var db		= Helper.Array.getByName(srv.databases,path.database);
			var idx		= Helper.Array.indexOfName(db.collections,path.collection); 
			
			if (idx >= 0) {
				Server.sortIndexes(response.indexList);
				db.collections[idx] = response;
				
				if (success) success(response);
			} else {
				Server.log("error",i18n.LOG_RETRIEVECOLLINFO_ERROR.replaceList($.extend(LOGPAR,{"##ERRORMSG##":i18n.LOG_RETRIEVECOLLINFO_NOTFOUND})));
				if (fail) fail();
			}
		}, function(result) {
			Server.log("error",i18n.LOG_RETRIEVECOLLINFO_ERROR.replaceList($.extend(LOGPAR,{"##ERRORMSG##":result.error})));
		});		
	},
	
	
	retrieveDatabaseInfo: function(path, success, fail) {
		var LOGPAR = {"##SERVERNAME##":Server.getByID(path.server).name, "##DBNAME##" : path.database};
		Server.Manager.retrieve_serverInfo(path, function(response) {			
			var srv		= Server.Connected[path.server];
			var idx		= Helper.Array.indexOfName(srv.databases,path.database);
			
			if (idx >= 0) {
				Server.sortCollections(response.collections);
				srv.databases[idx] = response;
				
				if (success) success(response);
			} else {
				Server.log("error",i18n.LOG_RETRIEVEDBINFO_ERROR.replaceList($.extend(LOGPAR,{"##ERRORMSG##":i18n.LOG_RETRIEVECOLLINFO_NOTFOUND})));
				if (fail) fail();
			}
		}, function(result) {
			Server.log("error",i18n.LOG_RETRIEVEDBINFO_ERROR.replaceList($.extend(LOGPAR,{"##ERRORMSG##":result.error})));
		});		
	},	
	
	
	retrieveServerInfo : function(server, success, fail, dontSort) {
		server = (typeof(server) == "string" ? {"server":server} : server);
		
		var LOGPAR = {"##SERVERNAME##" : Server.getByID(server.server).name};
		Server.Manager.retrieve_serverInfo(server, function(response) {
			var cnf	= Server.getByID(server.server);
			var srv = $.extend(true,{}, (cnf ? cnf : { "name":response.name, "addr" : response.addr, "port": response.port }));

			srv.databases = response.dbList;
			Server.connectedServers++;
			Server.Connected[response.id] = srv;

			if (!dontSort) Server.sortDatabases(srv.databases);
			success(srv);
		}, function(result) {
			Server.log("error",i18n.LOG_RETRIEVESRVRINFO_ERROR.replaceList($.extend(LOGPAR, {"##ERRORMSG##":result.error})));
			fail(result);
		});
	},
	
	
	retrieveConnectionInfo : function(success, fail) {
		var retrieveList	= [];
		var retrieveFn		= function() {
			if (retrieveList.length == 0 && success) {
				Server.sortConnected();
				success();
				return;
			}
			
			var server	= retrieveList.shift();
			
			Server.retrieveServerInfo(server, function() {
				retrieveFn();
			}, fail, true);
		}
		
		
		for (var id in Server.Connected) {
			retrieveList.push(id);
		}
		
		retrieveFn();		
	},
	
	connect : function(srvConf, success, fail) {
		var conf = $.extend(true,{},srvConf);
		
		if (!conf.replicas) {			
			conf.replicas	= [{"addr" : conf.addr, "port" : conf.port}];
		}
		
		Server.Manager.connectDB(conf,function(response) {
			Server.Connected[srvConf.id] = {};
			Server.retrieveConnectionInfo(success, fail);
		}, function(error) {
			if (fail) fail();
		});
	},
	
	
	disconnect : function(id, success, fail) {
		Server.Manager.disconnectDB(id, function() {
			delete Server.Connected[id];
			Server.connectedServers--;
			if (success) success();
		}, function() {
			alert("Erro desconectando DB");
		});
	}
};