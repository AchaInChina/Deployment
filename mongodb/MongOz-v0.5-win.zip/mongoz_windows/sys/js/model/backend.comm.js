/*
Copyright [2014] [Fábio Lutz / Diego Neumann]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

Backend.Comm  = function() {
	var that	= this;
	
	this.getParams = function(args) {
		if (!args) return undefined;
		
		var params	= "";
		var i		= 0;
		var oType	= null;
		var value	= null;
		
		for (var name in args) {
			value = args[name];
			if (value != undefined) {				
				switch (Helper.Object.getObjectType(value)) {
					case "object"	:
					case "array"	:
					case "boolean"	:
					case "null"		:
						value = JSON.stringify(args[name]);
					break;
				}
				
				params += (i++ > 0 ? "&" : "") + encodeURI(name) + "=" + encodeURI(value);
			}
		}
		
		return params;
	};
	
	
	this.escapeQuotes = function(body) {
		return body.replace(new RegExp('"', 'g'),'\"');
	};
	
	
	this.iframePost = function(control, data) {
		var url			= "/"+control.context+"/"+control.cmd+(control.path ? "/"+control.path : "");
		var method		= (control.method ? control.method : "POST");
		var cType		= (control.contentType ? control.contentType : "application/x-www-form-urlencoded");
		var body		= "";
		var autoSubmit	= (control.autoSubmit ? '<script type="text/javascript">document.getElementById("cmdForm").submit();</script>' : "");
		var scriptAfter	= (data.scriptAfter ? data.scriptAfter : "");
		
		if (data.params) {
			for (var name in data.params) {
				body += '<input type="hidden" name="'+name+'" value="'+Helper.Base64.encode(data.params[name])+'" />';
			}
		}
		
		if (data.body) body += data.body;
				
		if (control.callback) {
			Backend.IFrameHandler.setCallback(control.responseType, control.callback, control.callbackError);
		} else {
			Backend.IFrameHandler.clearCallback();
		}
		
		$("#iframeCommand").html(
			'<html><body>' +
				'<form id="cmdForm" method="'+method+'" action="'+url+'" enctype="'+cType+'" target="iframeCommandName">' +
					body +				
				'</form>' +
				scriptAfter +
				autoSubmit +
			'</body></html>'
		);
		
		console.log($("#iframeCommand").html());
	};
	
	
	
	this.commRequest = function(control, data, reqSuccess, reqFail) {
		var config = {};
		
		config.async	= true;
		config.type 	= control.method;
		config.url		= "/"+control.context+"/"+control.cmd+(control.path ? "/"+control.path : "")+(data.params ? "?"+that.getParams(data.params) : "");
		
		if (control.method == "POST" || control.method == "PUT") config.contentType	= (control.contentType ? control.contentType : "application/json");
		if (data.body) config.data = JSON.stringify(data.body);
		
		config.success = function(resData, textStatus, jqXHR) {
			LOG.debug(new Date().getTime()+" - dbRequest["+control.method+" "+config.url+"] SUCCESS: "+JSON.stringify(resData));
			if (reqSuccess) reqSuccess(resData);
		};
		
		config.error = function(jqXHR, textStatus, errorThrown) {
			LOG.debug(new Date().getTime()+" - dbRequest["+control.method+" "+config.url+"] ERROR: "+textStatus+"/"+jqXHR.responseText);
			if (reqFail) reqFail({ type	: "error", status : textStatus, error : errorThrown, serverMsg:jqXHR.responseText});
		};
		
		$.ajax(config);		
	};
};