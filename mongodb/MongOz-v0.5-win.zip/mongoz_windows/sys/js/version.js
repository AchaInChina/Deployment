var Version = {
	init	: function() {
		if (window.localStorage.getItem("version.ignoreCheck") == "yes") {
			LOG.important("Version release check turned off by settings - Ignoring...");
			return false;
		};
		
		var today		= Helper.Date.format();
		var lastCheck	= window.localStorage.getItem("version.lastCheck");
		
		if (today == lastCheck) {
			LOG.important("Version release check already done today - Ignoring...");
			return false;
		}
		
		LOG.important("Version release check process is ON");
		return true;
	},
	
	check : function() {
		if (!this.init()) return;
		
		$.ajax({
			type: 'GET',
			url: VERSION_CHECKURL,
			async: true,
			contentType: "application/json",
			jsonp: "Version.callback",
			dataType: 'jsonp',
		});
	},
	
	callback : function(json) {
		window.localStorage.setItem("version.lastCheck",Helper.Date.format());
		
		if (Helper.String.normalizeVersion(VERSION) < Helper.String.normalizeVersion(json.version)) {
			Dialog.Confirmation.open({
				title		: i18n.DLGVERSION_TITLE,
				message		: i18n.ALERT_NEWRELEASE.replaceList({"##CURVERSION##" : VERSION, "##NEWVERSION##" : json.version, "##NEWVERSIONNAME##" : json.name, "##NEWVERSIONDATE##" : json.released}),
				btnConfirm	: i18n.DLGVERSION_BTNDOWNLOAD,
				btnCancel	: i18n.DLGVERSION_BTNLATER,
				height		: 170
			}, function() {
				window.open(VERSION_DOWNLOADURL+"#"+json.name);
			});
		} else {
			LOG.important("Current application version is up to date");
		}
	}
};