if (!window.console) { window.console = {log: function(){} }; }

var LOG = {
	LEVEL		: {
		CRITICAL	: 1,
		IMPORTANT	: 9,
		ERROR		: 101,
		WARNING		: 1001,
		INFO		: 10001,
		DEBUG		: 999999
	},
	
	LEVEL_NAME : {
		1		: "CRITICAL",
		9		: "IMPORTANT",
		101 	: "ERROR",
		1001	: "WARNING",
		10001	: "INFO",
		999999	: "DEBUG"
	},
	
	CURRENT		: 999999,
	
	set : function(level, save) {
		level = Number(level);
		LOG.CURRENT = (level ? level : LOG.LEVEL.IMPORTANT);
		console.log("Log Level set to "+LOG.LEVEL_NAME[LOG.CURRENT] + " ["+LOG.CURRENT+"]");
		if (save) {
			window.localStorage.setItem("log.level",LOG.CURRENT);
			console.log("Log Level saved");
		}
	},
	
	init :function() {
		this.set(window.localStorage.getItem("log.level"));		
	},
	
	log : function(level, body) {
		if (level <= this.CURRENT) console.log(this.LEVEL_NAME[level]+" "+body);
	},
	
	critical	: function(body) { this.log(LOG.LEVEL.CRITICAL, body); },
	important	: function(body) { this.log(LOG.LEVEL.IMPORTANT, body); },
	error		: function(body) { this.log(LOG.LEVEL.ERROR, body); },
	warn		: function(body) { this.log(LOG.LEVEL.WARNING, body); },
	info		: function(body) { this.log(LOG.LEVEL.INFO, body); },
	debug		: function(body) { this.log(LOG.LEVEL.DEBUG, body); },
};

LOG.init();

